/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import journaldescriptor.JournalDescriptor;
import journaldescriptor.Output;

/**
 *
 * @author VISHNYAD
 */
public class JDSTRunner {
         public static void main(String[] args){
             String tc2011Path =args[0];
             String input = args[1];
             JournalDescriptor jd = new JournalDescriptor(tc2011Path);
             try {
                 Output out =  jd.getJDSetSTS(input);
                 System.out.println("Here are JDs: "+out.getJds());
                 System.err.println("Here are STSs: "+out.getSts());
             } catch (UnsupportedEncodingException ex) {
                 Logger.getLogger(JDSTRunner.class.getName()).log(Level.SEVERE, null, ex);
             }
     }
}
