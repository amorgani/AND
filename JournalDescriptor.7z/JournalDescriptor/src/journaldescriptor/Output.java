/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package journaldescriptor;

import java.util.List;

/**
 *
 * @author vishnyad
 */
public class Output {
  private List <String> jds;
  private List <String> sts;

    public Output(List<String> jds, List<String> sts) {
        this.jds = jds;
        this.sts = sts;
    }

    public List<String> getJds() {
        return jds;
    }

    public List<String> getSts() {
        return sts;
    }
  
}
