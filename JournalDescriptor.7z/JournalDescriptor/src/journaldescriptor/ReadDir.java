/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package journaldescriptor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author VISHNYAD
 */
public class ReadDir {


    String line = "";
    String cvsSplitBy = "\t";
//    String dirOut = "C:\\Users\\vishnyad\\ClinicalTrials\\JD+ST";
//    String dirOut = "U:\\My Documents\\virtualDisk\\2014\\sem_types";
    //read csv files for further processing
    public void getFiles(String inDir, String tc2011Path, String outDir, int choice){
        JournalDescriptor jd = new JournalDescriptor(tc2011Path);
         File directory = new File(inDir);
//                System.out.println("# of files in a directory: " + directory.listFiles().length);
                
                for (File file : directory.listFiles()) {
                   if(choice==0){
                       try {
                           getProfileList(file.getAbsolutePath(), jd, inDir, outDir);
                       } catch (IOException ex) {
                           Logger.getLogger(ReadDir.class.getName()).log(Level.SEVERE, null, ex);
                       }
                   }else{
                       try {
                           getDesc(file.getAbsolutePath(), jd, inDir, outDir);
                       } catch (IOException ex) {
                           Logger.getLogger(ReadDir.class.getName()).log(Level.SEVERE, null, ex);
                       }
                   }
                }
                jd.closeAPI();
    }

    private void getDesc (String csvFile, JournalDescriptor jd, String inDir, String outDir) throws IOException{
        List <String> tmp_pmids = new ArrayList();
     System.out.println("+++FILE+++ "+csvFile);
     Path filePath = Paths.get(csvFile.replace(inDir, outDir ));
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
                while ((line = br.readLine()) != null) {
                 
                     Output desc = new Output(null,null);
                    // send abstract text and get back JD
                    String[] profiles = line.split(cvsSplitBy);
                    
                    String abstractTxt = profiles[8];
                    String title = profiles[7];
                    
                    
                    
                        desc= jd.getJDSetSTS(abstractTxt+" "+title);
                    
                  
                  
                   
                    String jds_line = ""+desc.getJds();
                    String sts_line =""+desc.getSts();
                    jds_line = jds_line.replace("[]", "nul");
                    sts_line = sts_line.replace("[]", "nul");
                    jds_line=jds_line.replace("[", "").replace("]", "").replace(",", "|");
                    sts_line=sts_line.replace("[", "").replace("]", "").replace(",", "|");
//                    System.out.println(jds_line);
                    String new_result = profiles[0]+"\t"+profiles[1]+"\t"+profiles[2]+"\t"+profiles[3]+"\t"+profiles[4]+"\t"+profiles[5]+"\t"+profiles[6]+"\t"+jds_line+"\t"+sts_line;
//                    String new_result = profiles[0]+"\t"+profiles[1]+"\t"+profiles[2]+"\t"+profiles[3]+"\t"+profiles[4]+"\t"+profiles[5]+
//                            "\t"+profiles[6]+"\t"+profiles[7]+"\t"+profiles[8]+"\t"+profiles[9]+"\t"+profiles[10]+"\t"+profiles[11]+"\t"+profiles[12]+"\t"+
//                            profiles[13]+"\t"+profiles[16]+"\t"+profiles[17]+"\t"+profiles[18]+"\t"+profiles[19]+"\t"+profiles[20]+"\t"+profiles[21]+"\t"+jds_line;
                    tmp_pmids.add(new_result);
                }
                 Files.write(filePath, tmp_pmids, Charset.forName("UTF-8"));
    
    }
    private void getProfileList(String csvFile, JournalDescriptor jd, String inDir, String outDir ) throws IOException{
     List <String> tmp_pmids = new ArrayList();
     System.out.println("+++FILE+++ "+csvFile);
     Path filePath = Paths.get(csvFile.replace(inDir, outDir ));
             BufferedReader br = new BufferedReader(new FileReader(csvFile)) ;
                while ((line = br.readLine()) != null) {
                 
                     Output desc = new Output(null,null);
                    // send abstract text and get back JD
                    String[] profiles = line.split(cvsSplitBy);
                    System.out.println("Size of profile: "+profiles.length);
                    String abstractTxt = profiles[2];
                    String title = profiles[3];
                    String mesh = profiles[1];
                    if(!profiles[4].equalsIgnoreCase("null")) mesh = mesh+";"+profiles[4];
//                    String abstractTxt = profiles[14];
//                    String title = profiles[15];
//                    String mesh = profiles[13];
                    System.out.println("pmid "+profiles[0]);
//                    System.out.println("Abst: "+abstractTxt+" title "+title);
                    
                        desc= jd.getJDSetSTS(abstractTxt+" "+title+" "+mesh);
                    
                  
                  
                   
                    String jds_line = ""+desc.getJds();
                    String sts_line =""+desc.getSts();
                    jds_line = jds_line.replace("[]", "nul");
                    sts_line = sts_line.replace("[]", "nul");
                    jds_line=jds_line.replace("[", "").replace("]", "").replace(",", "|");
                    sts_line=sts_line.replace("[", "").replace("]", "").replace(",", "|");
//                    System.out.println(jds_line);
                    String new_result = profiles[0]+"\t"+jds_line+"\t"+sts_line+"\t"+title+"\t"+abstractTxt+"\t"+mesh;
//                    String new_result = profiles[0]+"\t"+profiles[1]+"\t"+profiles[2]+"\t"+profiles[3]+"\t"+profiles[4]+"\t"+profiles[5]+
//                            "\t"+profiles[6]+"\t"+profiles[7]+"\t"+profiles[8]+"\t"+profiles[9]+"\t"+profiles[10]+"\t"+profiles[11]+"\t"+profiles[12]+"\t"+
//                            profiles[13]+"\t"+profiles[16]+"\t"+profiles[17]+"\t"+profiles[18]+"\t"+profiles[19]+"\t"+profiles[20]+"\t"+profiles[21]+"\t"+jds_line;
                    tmp_pmids.add(new_result);
                }

                   

                         Files.write(filePath, tmp_pmids, Charset.forName("UTF-8"));

            
              
        }
    
  
     public static void main(String[] args){
         String inDir = args[0];
//         String inDir = "C:\\Users\\vishnyad\\MEDLINE2016\\UniqueAbstract\\";
         String outDir = args[1];
//         String outDir = "C:\\Users\\vishnyad\\MEDLINE2016\\JD_and_ST\\";
         String tc2011Path = args[2];
//         String tc2011Path = "U:\\My Documents\\tc2011\\";
         String choice =args [3];
        ReadDir dirReader = new ReadDir ();
        if(choice.contains("0")){
         dirReader.getFiles(inDir, tc2011Path, outDir, 0);
        }
        else {
            dirReader.getFiles(inDir, tc2011Path, outDir, 1);
        }
         
     }
}
