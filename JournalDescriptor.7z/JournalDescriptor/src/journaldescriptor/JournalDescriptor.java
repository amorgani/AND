/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package journaldescriptor;

import gov.nih.nlm.nls.tc.Api.JdiApi;
import gov.nih.nlm.nls.tc.Api.StiApi;
import gov.nih.nlm.nls.tc.FilterApi.InputFilterOption;
import gov.nih.nlm.nls.tc.FilterApi.LegalWordsOption;
import gov.nih.nlm.nls.tc.FilterApi.OutputFilter;
import gov.nih.nlm.nls.tc.FilterApi.OutputFilterOption;
import gov.nih.nlm.nls.tc.Jdi.JournalDescriptors;
import gov.nih.nlm.nls.tc.Lib.Configuration;
import gov.nih.nlm.nls.tc.Lib.Count2f;
import gov.nih.nlm.nls.tc.Sti.SemanticTypes;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Vector;


/**
 *
 * @author vishnyad
 */
public class JournalDescriptor {

//    @SuppressWarnings("UseOfObsoleteCollectionType")
    private Hashtable<String, String> properties;
    private Configuration conf ;
    private JdiApi api ;
    private StiApi st_api ;
    private JournalDescriptors jds;
    private SemanticTypes sts;
    private InputFilterOption inputFilterOption;
    
  //"U:\\My Documents\\tc2011\\"
//    @SuppressWarnings("UseOfObsoleteCollectionType")
    public JournalDescriptor(String tcPath) {
        this.properties = new Hashtable();
      
        this.conf = new Configuration("data.Config.tc", true);
        this.properties.put("ROOT_DIR", tcPath);
			this.api = new JdiApi(properties);
                        this.st_api = new StiApi(conf);
                        this.sts = st_api.GetSemanticTypes();
                        this.jds = api.GetJournalDescriptors();
                       
                        this.inputFilterOption
				= new InputFilterOption(LegalWordsOption.DEFAULT_JDI);
    }
	public Output getJDSetSTS(String inText) throws UnsupportedEncodingException
	{
                        Output res = null;
			Vector<Count2f> scores = api.GetJdiScoresByTextMesh(inText,
				inputFilterOption);
			
			Vector<Count2f> sts_scores = st_api.GetStiScoresByText(inText,
				inputFilterOption);

			// setup output filter option
			OutputFilterOption outputFilterOption = new OutputFilterOption();
			outputFilterOption.SetOutputNum(3);

			String resultStr = OutputFilter.ProcessText(scores, jds,
				outputFilterOption);
                        String result_sts = OutputFilter.ProcessText( sts_scores, sts, outputFilterOption);
                        String[] tmp = resultStr.split("\n");
                        String[] sts_tmp = result_sts.split("\n");
//			System.out.println(resultStr);
//			System.out.println("================");
//			System.out.println(result_sts);
                        java.util.List <String> result_jds;
                        java.util.List <String> results_sts;
                             result_jds = new LinkedList();
                             results_sts = new LinkedList();
                             if (tmp.length>5){
                             
                                for (int i = 0; i<tmp.length; i++){
                                    if(i==2||i==3||i==4){
        //                                byte[] b1 = tmp[i].getBytes("UTF-8");
        //                                String b2 = new String(b1, "UTF-8");
                                        String[] ttt= tmp[i].split("\\|");
                                        String blyad = ttt[3].trim();
                                        blyad = blyad.replace(",", ".");
//                                        System.out.println("length"+ttt.length+" "+blyad);
                                        result_jds.add(blyad);

            // Show what happened
                                    }
                                }
                             }
                       //semantic types
                                                   if (sts_tmp.length>5){
                             
                                for (int i = 0; i<sts_tmp.length; i++){
                                    if(i==2||i==3||i==4){
        //                                byte[] b1 = tmp[i].getBytes("UTF-8");
        //                                String b2 = new String(b1, "UTF-8");
                                        String[] ttt= sts_tmp[i].split("\\|");
                                        String blyad = ttt[4].trim();
                                        blyad = blyad.replace(",", ".");
//                                        System.out.println("lengthsts"+ttt.length+" "+blyad);
                                        results_sts.add(blyad);

            // Show what happened
                                    }
                                }
                             }
                                                   res = new Output(result_jds, results_sts);
    System.out.println("JDSHere: " +result_jds);
//    System.out.println("STSHere: " +results_sts);
//    System.out.println("size: " +res.getJds().isEmpty()+" "+res.getSts().isEmpty());
			
	return res;		
		
	}
        public void closeAPI(){
            this.api.Close();
        }
        
       
}
