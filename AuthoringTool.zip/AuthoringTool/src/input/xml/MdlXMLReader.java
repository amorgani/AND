/**
 * Copyright (c) 2012 scireum GmbH - Andreas Haufler - aha@scireum.de
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
package input.xml;

import javax.xml.xpath.XPathExpressionException;

import com.scireum.open.xml.NodeHandler;
import com.scireum.open.xml.StructuredNode;
import com.scireum.open.xml.XMLReader;
import input.xml.model.MDLProfile;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import output.xml.medline.TSVWriter;

/**
 * Small example class which show how to use the {@link XMLReader}.
 */
public class MdlXMLReader {


    private String outputFile ="";
    private PrintWriter out = null;
    private TSVWriter tsvWriter = new TSVWriter();
    public void extractXmlEnt(InputStream fis) throws ParserConfigurationException, SAXException, IOException {
        
       
        XMLReader r = new XMLReader();

        // We can add several handlers which are triggered for a given node
        // name. The complete sub-dom of this node is then parsed and made
        // available as a StructuredNode
        r.addHandler("MedlineCitation", new NodeHandlerImpl());
        // Parse our little test file. Note, that this could be easily processed
        // with a DOM-parser and only serves as showcase. Real life input files
        // would be much bigger...

        r.parse(fis);
        out.close();
//        System.out.println("MDLXMLREADER, number of names "+profile_lst.size());
//        author_count.entrySet().stream().forEach((entry) -> {
//            int counter = entry.getValue();
////            if (counter > 1) {
////                System.out.println(entry.getKey() + "  " + counter);
////            }
//        }
//        );

    }

    public MdlXMLReader(String ouputF) {
        this.outputFile = ouputF;
    }

    private class NodeHandlerImpl implements NodeHandler {

        public NodeHandlerImpl() {
        }

        @Override
        public void process(StructuredNode node) {
            try {
            out = new PrintWriter(new BufferedWriter(new FileWriter(outputFile, true)));
                String pmid ;
                String lang ;
                String year;
                String medlineTA ;
                String collective_n ;
                List<String> affiliations;
                List<StructuredNode> meshList;
                List<StructuredNode> authorList;
                List<StructuredNode> keywordsList;
                String abtsrTxt;
                Set<String> coautors = new HashSet();
                String title;
                List<StructuredNode> grants;
                List <StructuredNode> clinic_trials;
                // We can now conveniently query the sub-dom of each node
                // using XPATH:
                pmid = node.queryString("PMID/text()");
                lang = node.queryString("//Language");
                medlineTA = node.queryString("//MedlineJournalInfo/MedlineTA");
                grants = node.queryNodeList("//GrantList");
                authorList = node.queryNodeList("//AuthorList/Author");
                meshList = node.queryNodeList("//MeshHeadingList/MeshHeading");
                clinic_trials= node.queryNodeList("//DataBankList/DataBank");
                keywordsList = node.queryNodeList("//KeywordList");
                
//                    String  collective_n = node.queryString("//AuthorList/CollectiveName[1]");
year = node.queryString("//Article/Journal/JournalIssue/PubDate/Year");
if (year==null){
    year = node.queryString("//MedlineCitation/DateCreated/Year/text()");
//    System.out.println("HERE FUCKING YEAR: "+year);
} 
abtsrTxt=node.queryString("//Abstract/AbstractText/text()");
title = node.queryString("//ArticleTitle/text()");
int count_auth_order = 0;
List<MDLProfile> tmp_profile_lst = new ArrayList();
for (StructuredNode temp : authorList) {
    try {
        affiliations = new ArrayList<>();
        MDLProfile profile = new MDLProfile();
        count_auth_order++;
        
        String fName = temp.queryString("ForeName/text()");
        String lName = temp.queryString("LastName/text()");
               
        String iName = temp.queryString("Initials/text()");
        List<StructuredNode> affil = temp.queryNodeList("AffiliationInfo");
        collective_n = temp.queryString("//CollectiveName/text()");
        
        if(affil.isEmpty()){
             String affilOld = temp.queryString("Affiliation/text()");
                
             affiliations.add(affilOld);
        }
        else{
        
                for (StructuredNode a_tmp : affil) {
                    try {
                        affiliations.add(a_tmp.queryString("Affiliation") );
//                        System.out.println("XMLMedlineReader " + a_tmp.queryString("Affiliation"));
                    } catch (XPathExpressionException ex) {
                        java.util.logging.Logger.getLogger(MdlXMLReader.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
        }

//          Affilations
//                        if(affiliations.size()>1) System.out.println("Multiple affiliations:"+ pmid+" "+lName);
profile.setAffiliat(affiliations);
//                        System.out.println("XMLMedlineReader " + pmid);
//creating the profile per article, if no person name -> not collecting
if (lName != null) {
    coautors.add(lName + " " + iName);
    profile.setMedlineTA(medlineTA);
    profile.setYear(year);
    profile.setLang(lang);
    profile.setAuth_order(count_auth_order);
    profile.setColl_name(collective_n);//Descriptors
    profile.setAbstractTxt(abtsrTxt);
    profile.setTitle(title);
    
    if (!meshList.isEmpty()) {
        
        Map<String, String> major = new HashMap();
        Set<String> mesh_desc = new HashSet();
        for (StructuredNode tmp: meshList){
            String majTopic = tmp.queryString("DescriptorName/@MajorTopicYN");
            String meshID = tmp.queryString("DescriptorName/@UI");
            String descriptor = tmp.queryString("DescriptorName/text()");
            major.put(meshID, majTopic);
            mesh_desc.add(descriptor);
        }
//        meshList.stream().forEach((tmp) -> {
//            String majTopic = tmp.queryString("DescriptorName/@MajorTopicYN");
//            String meshID = tmp.queryString("DescriptorName/@UI");
//            String descriptor = tmp.queryString("DescriptorName/text()");
//            major.put(meshID, majTopic);
//            mesh_desc.add(descriptor);
//        });
        profile.setMajor(major);
        profile.setMesh_desc(mesh_desc);
        
    }
    //Clinical trials
    if(!clinic_trials.isEmpty()){
        String name_db_clin = "";
        String accessionNumber="";
        for(StructuredNode trial: clinic_trials){
           String  tmpname_db_clin = "";
               name_db_clin=  trial.queryString("DataBankName/text()");
               System.out.println(name_db_clin);
               if(name_db_clin!=null){
                    if(tmpname_db_clin.length()<2&& name_db_clin.contains(".gov")) {

                        accessionNumber= trial.queryString("AccessionNumberList/AccessionNumber/text()");
        //                System.out.println(pmid+" trial: "+name_db_clin+" num: "+accessionNumber);


                    } 
                    else {
                        name_db_clin = "null";
                        accessionNumber="null";
                    }

               }
        }
             profile.setClinic_tr_name(name_db_clin);
             profile.setClinic_trial_num(accessionNumber);
        
    }
    //Grants
    if(!grants.isEmpty()){
        String tmp_id="";
        String tmp_country="";
        String tmp_agency="";
        int count_id =0;
        for (StructuredNode tmp: grants){
            if(count_id!=0){
                tmp_id=tmp_id+";"+ tmp.queryString("GrantID/text()");
                tmp_country=tmp_country+";"+tmp.queryString("Country/text()");
                tmp_agency = tmp_agency+";"+tmp.queryString("Agency/text()");
            }
            else{
                tmp_id=tmp.queryString("GrantID/text()");
                tmp_agency=tmp.queryString("Agency/text()");
                tmp_country=tmp.queryString("Country/text()");
            }
           count_id++;
        }
        profile.setGrantAgency(tmp_agency);
        profile.setGrantCountry(tmp_country);
        profile.setGrantID(tmp_id);
       

    }
  
//keywords
if (!keywordsList.isEmpty()) {
//                            System.out.println("Keywords size "+keywordsList.size());
Map<String, String> major_kw = new HashMap();
for (StructuredNode tmp:keywordsList){
 String majorKW = tmp.queryString("Keyword/@MajorTopicYN");
        String keyword = tmp.queryString("Keyword");
        major_kw.put(keyword, majorKW);
}
//keywordsList.stream().forEach((tmp) -> {
//    try {
//        String majorKW = tmp.queryString("Keyword/@MajorTopicYN");
//        String keyword = tmp.queryString("Keyword");
//        major_kw.put(keyword, majorKW);
//    } catch (XPathExpressionException ex) {
//        java.util.logging.Logger.getLogger(MdlXMLReader.class.getName()).log(Level.SEVERE, null, ex);
//    }
//});
profile.setKeyword_major(major_kw);
}
if (pmid != null) {
    profile.setPmid(pmid);
}
profile.setlName(lName);
if (fName != null) {
    profile.setfName(fName);
}
if (iName != null) {
    profile.setfName_init(iName);
}
//                        num_names++;

//                        System.out.println("MDLXMLReader affil  "+affil);
}
if (profile.getlName() != null) {
//     System.out.println(profile.getPmid()+" "+profile.getlName()+" "+profile.getLang());
    tmp_profile_lst.add(profile);
}
    } catch (XPathExpressionException ex) {
        java.util.logging.Logger.getLogger(MdlXMLReader.class.getName()).log(Level.SEVERE, null, ex);
    }
    
}

//Adding co-authors

if (!coautors.isEmpty() && coautors.size() > 1) {
    tmp_profile_lst.stream().map(new Function<MDLProfile, MDLProfile>() {
        @Override
        public MDLProfile apply(MDLProfile tmp_prof) {
            String full_name = tmp_prof.getlName() + " " + tmp_prof.getfName_init();
            
            Set<String> updated_coAutrs = new HashSet<>();
            coautors.stream().filter((u_autors) -> (!u_autors.equalsIgnoreCase(full_name))).forEach((u_autors) -> {
                updated_coAutrs.add(u_autors);
            });
//                        System.out.println("check " +" main "+ full_name+ updated_coAutrs);

tmp_prof.setCoautors(updated_coAutrs);

return tmp_prof;


//printing profiles to file
        }
    }).forEach((MDLProfile tmp_prof) -> {
        try {
            tsvWriter.write( tmp_prof,out);
            
        } catch (IOException ex) {
            Logger.getLogger(MdlXMLReader.class.getName()).log(Level.SEVERE, null, ex);
        }
    });
} else if (!coautors.isEmpty() && coautors.size() == 1) {
    tsvWriter.write(tmp_profile_lst.get(0), out);
//                    profile_lst.addAll(tmp_profile_lst);
}

//          System.out.println("Profile size "+profile_lst.size());
            } catch (XPathExpressionException | IOException ex) {
                java.util.logging.Logger.getLogger(MdlXMLReader.class.getName()).log(Level.SEVERE, null, ex);
            }
            out.close();
        }
    }

}
