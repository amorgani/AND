/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.xml;

import java.io.FileInputStream;
import java.io.IOException;

import java.util.zip.GZIPInputStream;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;



/**
 *
 * @author VISHNYAD
 */
public class GZipReader {


public void readAuthors(String filename, String outputF) throws IOException, ParserConfigurationException, SAXException{



        GZIPInputStream gzip;
   
        System.out.println("File: "+filename+" is in process");
        gzip = new GZIPInputStream(new FileInputStream(filename));
     
        MdlXMLReader r = new MdlXMLReader(outputF);
         
                r.extractXmlEnt(gzip);
            
//               System.out.println("Number of profiles in GZIP: "+file_profiles.size());
          
       
            
            
  
   
    
}
public void readPMIDS(String filename, String outputF) throws IOException, ParserConfigurationException, SAXException{



        GZIPInputStream gzip;
   
        System.out.println("File: "+filename+" is in process");
        gzip = new GZIPInputStream(new FileInputStream(filename));
         MdlXMLReader m = new MdlXMLReader(outputF);
       
       m.extractXmlEnt(gzip);
//        AbstractTitleReader r = new AbstractTitleReader(outputF);
         
//                r.extractXmlEnt(gzip);
            
//               System.out.println("Number of profiles in GZIP: "+file_profiles.size());
          
       
            
            
  
   
    
}

}
