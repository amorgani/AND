/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.xml;

import com.scireum.open.xml.NodeHandler;
import com.scireum.open.xml.StructuredNode;
import com.scireum.open.xml.XMLReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.xml.sax.SAXException;

/**
 *
 * @author VISHNYAD
 */
public class AbstractTitleReader {
    private String outputFile ="";


        public void extractXmlEnt(InputStream fis) throws ParserConfigurationException, SAXException, IOException {

        XMLReader r = new XMLReader();

        // We can add several handlers which are triggered for a given node
        // name. The complete sub-dom of this node is then parsed and made
        // available as a StructuredNode
        r.addHandler("MedlineCitation", new AbstractTitleReader.NodeHandlerImpl());
        // Parse our little test file. Note, that this could be easily processed
        // with a DOM-parser and only serves as showcase. Real life input files
        // would be much bigger...

        r.parse(fis);
     
//        System.out.println("MDLXMLREADER, number of names "+profile_lst.size());
//        author_count.entrySet().stream().forEach((entry) -> {
//            int counter = entry.getValue();
////            if (counter > 1) {
////                System.out.println(entry.getKey() + "  " + counter);
////            }
//        }
//        );

    }
      public AbstractTitleReader(String ouputF) {
        this.outputFile = ouputF;
    }

    private class NodeHandlerImpl implements NodeHandler {

        public NodeHandlerImpl() {
        }

        @Override
        public void process(StructuredNode node) {
            try {
                JSONObject obj = new JSONObject();
                JSONArray glist = new JSONArray();
                JSONArray mlist = new JSONArray();
                
                
                // We can now conveniently query the sub-dom of each node
                // using XPATH:
                String title = node.queryString("//ArticleTitle/text()");
                String abstractTxt = node.queryString("//Abstract/AbstractText");
                List<StructuredNode> grantLst = node.queryNodeList("GrantList/Grant");
                List<StructuredNode> meshLst = node.queryNodeList("MeshHeadingList/MeshHeading");
                String pmid = node.queryString("PMID/text()");
//                System.out.println("Processing pmid: "+pmid);
                obj.put("pmid", pmid);
                obj.put("title", title);
                obj.put("abstractTxt", abstractTxt);
                if(grantLst!=null){
                    for (StructuredNode item: grantLst){
                        glist.add(item.queryString("GrantID/text()"));
                        glist.add(item.queryString("Acronym/text()"));
                        glist.add(item.queryString("Agency/text()"));
                        glist.add(item.queryString("Country/text()"));

                    }
                    obj.put("grant", glist);
                }
                if(meshLst!=null){
                    for (StructuredNode item: meshLst){
                        if(item.queryString("DescriptorName/text()")!=null){
                            mlist.add(item.queryString("DescriptorName/text()"));
                        }
                        
                        if(item.queryString("QualifierName/text()")!=null)
                            mlist.add(item.queryString("QualifierName/text()"));
                        
                    }
                    obj.put("mesh", mlist);
                }
                
                FileWriter file = new FileWriter(outputFile+"\\"+pmid+".json");
                file.write(obj.toJSONString());
                file.flush();
//                System.out.println("Done");
            } catch (XPathExpressionException | IOException ex) {
                Logger.getLogger(AbstractTitleReader.class.getName()).log(Level.SEVERE, null, ex);
            }
           
            
            
        }
    }

}
