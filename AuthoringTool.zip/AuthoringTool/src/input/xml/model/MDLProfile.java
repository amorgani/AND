/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.xml.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author VISHNYAD
 */
public class MDLProfile {
    private String fName =null;
    private String lName = null;
    private String fName_init = null;
    private String pmid =null;
    private String year = null;
    private Boolean article=false;
    private List <String> affiliat=new ArrayList<>();
    private String lang = null;
    private String medlineTA = null;
    private Integer auth_order = 0;
    private Map <String, String> major = new HashMap();
    private Set<String> mesh_desc = new HashSet();
    private Map <String, String> keyword_major = new HashMap();
    private String coll_name = null;
    private Set <String> coautors = new HashSet();
    private String abstractTxt = null;
    private String title = null;
    private String grantID=null;
    private String grantCountry=null;
    private String grantAgency =null;
    private String clinic_trial_num = null;
    private String clinic_tr_name=null;

    public String getClinic_tr_name() {
        return clinic_tr_name;
    }

    public String getClinic_trial_num() {
        return clinic_trial_num;
    }

    public void setClinic_tr_name(String clinic_tr_name) {
        this.clinic_tr_name = clinic_tr_name;
    }

    public void setClinic_trial_num(String clinic_trial_num) {
        this.clinic_trial_num = clinic_trial_num;
    }

    

    public String getGrantAgency() {
        return grantAgency;
    }

    public String getGrantCountry() {
        return grantCountry;
    }

    public String getGrantID() {
        return grantID;
    }

    public void setGrantAgency(String grantAgency) {
        this.grantAgency = grantAgency;
    }

    public void setGrantCountry(String grantCountry) {
        this.grantCountry = grantCountry;
    }

    public void setGrantID(String grantID) {
        this.grantID = grantID;
    }
    
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    
    public void setAbstractTxt(String abstractTxt) {
        this.abstractTxt = abstractTxt;
    }

    public String getAbstractTxt() {
        return abstractTxt;
    }
    
    public Set<String> getCoautors() {
        return coautors;
    }

    public void setCoautors(Set<String> coautors) {
        this.coautors = coautors;
    }

   
    public void setColl_name(String coll_name) {
        this.coll_name = coll_name;
    }

    public String getColl_name() {
        return coll_name;
    }
    
    

    public Map<String, String> getKeyword_major() {
        return keyword_major;
    }

    public void setKeyword_major(Map<String, String> keyword_major) {
        this.keyword_major = keyword_major;
    }


    
    
    
    public Integer getAuth_order() {
        return auth_order;
    }

    public Set<String> getMesh_desc() {
        return mesh_desc;
    }

    public void setMesh_desc(Set<String> mesh_desc) {
        this.mesh_desc = mesh_desc;
    }

    public void setAuth_order(Integer auth_order) {
        this.auth_order = auth_order;
    }

    public Map<String, String> getMajor() {
        return major;
    }

    public void setMajor(Map<String, String> major) {
        this.major = major;
    }
    
    


    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getMedlineTA() {
        return medlineTA;
    }

    public void setMedlineTA(String medlineTA) {
        this.medlineTA = medlineTA;
    }

    public List<String> getAffiliat() {
        return affiliat;
    }

    public void setAffiliat(List<String> affiliat) {
        this.affiliat = affiliat;
    }


   
    
    public String getPmid() {
        return pmid;
    }

    public void setPmid(String pmid) {
        this.pmid = pmid;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Boolean getArticle() {
        return article;
    }

    public void setArticle(Boolean article) {
        this.article = article;
    }
    
    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getfName_init() {
        return fName_init;
    }

    public void setfName_init(String fName_init) {
        this.fName_init = fName_init;
    }
    
}
