/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.xml;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author VISHNYAD
 */
public class FListReader {
     private GZipReader gzipreader = new GZipReader();
    public void fileFound(String in, String out) throws IOException, ParserConfigurationException, SAXException {
 
   File directory = new File(in);
//   File directory = new File("U:\\My Documents\\virtualDisk\\MEDLINEarch\\MDLgzipTest\\");
   System.out.println("# of files in a directory: "+directory.list().length);
   for(File file : directory.listFiles()){
           String filenameInput=file.getName();
           String inputFileAbsPath = file.getAbsolutePath();
            String result = filenameInput.replace(".xml.gz", ".csv");
//                   String filenameOutput=result.replace("U:\\My Documents\\virtualDisk\\MEDLINEarch\\MDLgzipTest\\", "U:\\My Documents\\virtualDisk\\MEDLINEarch\\MdlGzipOut\\");
                   String filenameOutput=out+result;
                    System.out.println("Writing to "+filenameOutput);
//            List <MDLProfile> profiles = 
                if (filenameInput.contains(".xml.gz")){
                    gzipreader.readPMIDS(inputFileAbsPath, filenameOutput);
                }
//                    OutputWriter out = new OutputWriter();
//                    out.writeOutput(filenameOutput, profiles);
         }
   
}
//    private void writeJSONs () throws IOException, ParserConfigurationException, SAXException{
//        File directory = new File("U:\\My Documents\\virtualDisk\\email\\");
//            System.out.println("# of files in a directory: "+directory.list().length);
//             for(File file : directory.listFiles()){
//                String filenameInput=file.getAbsolutePath();
//                    String result = file.getName();
//                    String outputF = result.replace(".xml.gz", "");
//                    String outJson = "U:\\My Documents\\virtualDisk\\PMIDS\\"+outputF;
//                    Path path = Paths.get(outJson);
//                    Files.createDirectories(path);
//                    
////            List <MDLProfile> profiles = 
//                    gzipreader.readPMIDS(filenameInput, outJson);
////                    OutputWriter out = new OutputWriter();
////                    System.out.println("Writing to "+filenameOutput);
////                    out.writeOutput(filenameOutput, profiles);
//         }
//    }
    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException{
        String inputPath = args[0].replace("*", ""); //U:\\My Documents\\virtualDisk\\2014\\medIN\\
        String outputPath =args[1].replace("*", ""); //U:\\My Documents\\virtualDisk\\2014\\tmp_medOUT\\
        System.out.println(" 1:"+inputPath);
        System.out.println(" 2:"+outputPath);
    FListReader tmp = new FListReader();
    tmp.fileFound(inputPath, outputPath);
   
//     tmp.writeJSONs();
  
}
}
