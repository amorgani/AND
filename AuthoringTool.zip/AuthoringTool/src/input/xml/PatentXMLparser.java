/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.xml;

import com.scireum.open.xml.NodeHandler;
import com.scireum.open.xml.StructuredNode;
import com.scireum.open.xml.XMLReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;
import output.xml.medline.TSVWriter;

/**
 *
 * @author VISHNYAD
 */
public class PatentXMLparser {

    private String outputFile = "";
    private PrintWriter out = null;
    private TSVWriter tsvWriter = new TSVWriter();

    public void extractXmlEnt(InputStream fis) throws ParserConfigurationException, SAXException, IOException {

        XMLReader r = new XMLReader();

        // We can add several handlers which are triggered for a given node
        // name. The complete sub-dom of this node is then parsed and made
        // available as a StructuredNode
        r.addHandler("MedlineCitation", new NodeHandlerImpl());
        // Parse our little test file. Note, that this could be easily processed
        // with a DOM-parser and only serves as showcase. Real life input files
        // would be much bigger...

        r.parse(fis);
        out.close();
//        System.out.println("MDLXMLREADER, number of names "+profile_lst.size());
//        author_count.entrySet().stream().forEach((entry) -> {
//            int counter = entry.getValue();
////            if (counter > 1) {
////                System.out.println(entry.getKey() + "  " + counter);
////            }
//        }
//        );

    }

    public PatentXMLparser(String ouputF) {
        this.outputFile = ouputF;
    }

    private class NodeHandlerImpl implements NodeHandler {

        public NodeHandlerImpl() {
        }

        @Override
        public void process(StructuredNode node) {

            try {
                out = new PrintWriter(new BufferedWriter(new FileWriter(outputFile, true)));
                String pmid;
                String lang;
                String year;
                String medlineTA;
                String collective_n;
                List<String> affiliations;
                List<StructuredNode> meshList;
                List<StructuredNode> authorList;
                List<StructuredNode> keywordsList;
                List<StructuredNode> grants;
                Set<String> coautors = new HashSet();
                
                // We can now conveniently query the sub-dom of each node
                // using XPATH:
                pmid = node.queryString("PMID/text()");
                lang = node.queryString("//Language");
                medlineTA = node.queryString("//MedlineJournalInfo/MedlineTA");
                
                authorList = node.queryNodeList("//AuthorList/Author");
                meshList = node.queryNodeList("//MeshHeadingList/MeshHeading");
                
                keywordsList = node.queryNodeList("//KeywordList");
                grants =  node.queryNodeList("//GrantList");
//                    String  collective_n = node.queryString("//AuthorList/CollectiveName[1]");
//                System.out.println(node.queryString("//PubDate/Year"));
year = node.queryString("//Article/Journal/JournalIssue/PubDate/Year");
            } catch (IOException | XPathExpressionException ex) {
                Logger.getLogger(PatentXMLparser.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
