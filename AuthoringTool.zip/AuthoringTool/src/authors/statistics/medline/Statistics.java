/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authors.statistics.medline;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author VISHNYAD
 */
public class Statistics {
    private HashMap<String, Integer> author_count = new HashMap();
    private Integer null_names = 0;
    private Integer num_names = 0;
    private Integer n_pmids = 0;
    private Set<String> na_pmids = new HashSet();

    public HashMap<String, Integer> getAuthor_count() {
        return author_count;
    }

    public void setAuthor_count(HashMap<String, Integer> author_count) {
        this.author_count = author_count;
    }

    public Integer getNull_names() {
        return null_names;
    }

    public void setNull_names(Integer null_names) {
        this.null_names = null_names;
    }

    public Integer getNum_names() {
        return num_names;
    }

    public void setNum_names(Integer num_names) {
        this.num_names = num_names;
    }

    public Integer getN_pmids() {
        return n_pmids;
    }

    public void setN_pmids(Integer n_pmids) {
        this.n_pmids = n_pmids;
    }

    public Set<String> getNa_pmids() {
        return na_pmids;
    }

    public void setNa_pmids(Set<String> na_pmids) {
        this.na_pmids = na_pmids;
    }
    
}
