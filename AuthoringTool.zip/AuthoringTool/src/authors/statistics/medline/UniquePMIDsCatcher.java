/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authors.statistics.medline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author VISHNYAD
 */
public class UniquePMIDsCatcher {
        String line = "";
    String cvsSplitBy = "\t";
    Set <String> pmids = new HashSet();
    
    private Set<String> getUniquePmids(String csvFile ){
     Set <String> tmp_pmids = new HashSet();
   
            try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                while ((line = br.readLine()) != null) {

                    // use comma as separator
                    String[] country = line.split(cvsSplitBy);
                        tmp_pmids.add(country[0]+"\t"+country[13]+"\t"+country[14]+"\t"+country[15]);

                }

                   

    //                     Files.write("wer", list, Charset.forName("UTF-8"));

            } catch (IOException e) {
            }
                return tmp_pmids;
        }
    
    public void readFiles(String pathToDir) throws IOException {
       File directory = new File(pathToDir);
       for(File file : directory.listFiles()){
           String filename = file.getAbsolutePath();
           pmids.addAll(getUniquePmids(filename));
       }
       System.out.println("# of files in a directory: "+directory.list().length);
       System.out.println("# of pmids: "+pmids.size());
       Path path = Paths.get("U:\\My Documents\\virtualDisk\\UniquePMIDS\\pmids775_776.txt");
       List<String> list;
            list = new ArrayList<>(pmids);
            Files.write(path, list, Charset.forName("UTF-8"));
   
    }
    
//     public static void main(String[] args) throws IOException{
//         UniquePMIDsCatcher p = new UniquePMIDsCatcher();
//         p.readFiles("U:\\My Documents\\virtualDisk\\MEDLINEarch\\MdlOrgLoc\\");
//     }
    }

