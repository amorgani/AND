/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package output.xml.medline;

import input.xml.model.MDLProfile;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author VISHNYAD
 */
public class TSVWriter {
  public void write ( MDLProfile profile, PrintWriter out) throws IOException{
     //19 columns
          String line = profile.getPmid()+"\t"+profile.getlName()+"\t"+profile.getfName_init()+"\t"+profile.getfName()+"\t"+profile.getAuth_order()+"\t"+profile.getAffiliat()+"\t"+profile.getLang()
                        +"\t"+profile.getYear()+"\t"+profile.getColl_name()+"\t"+profile.getMedlineTA()+"\t"+profile.getKeyword_major()+"\t"+profile.getCoautors()+"\t"+profile.getMesh_desc()+"\t"+profile.getAbstractTxt()+"\t"+profile.getTitle()
                  +"\t"+profile.getGrantID()+"\t"+profile.getGrantAgency()+"\t"+profile.getGrantCountry()+"\t"+profile.getClinic_tr_name()+"\t"+profile.getClinic_trial_num();
                line=line.replaceAll("\\{\\}", "null").replaceAll("\\[\\]", "null");
                line=line.replace("[", "");
                line=line.replace("]", "");
                line=line.replace("}", "");
                line=line.replace("{", "");
                line= line.replaceAll("(\\r|\\n)", "");
//                System.out.println(line);
                out.println(line);
                
      
  }  
}
