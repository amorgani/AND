/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package output.xml.medline;

import input.xml.model.MDLProfile;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author VISHNYAD
 */
public class OutputWriter {
    public void writeOutput(String path, List <MDLProfile> profiles ){
        try {
            
            Path file = Paths.get(path);
            System.out.printf("path ", path);
            List <String> lines = new ArrayList<>();
        
            String header ="PMID\tFullNAME\tLastName\tFirstName\tInitials\tAuthor_ord\tAffiliations\tLang\tYear\tCollectiveName\tMedlineTA\tMajorKeyWrds\tcoAutors";
            lines.add(header);
            for(MDLProfile profile: profiles){
                  String line = profile.getPmid()+"\t"+profile.getlName()+" "+profile.getfName_init()+"\t"+profile.getlName()+"\t"+profile.getfName()+"\t"+profile.getfName_init()+"\t"+profile.getAuth_order()+"\t"+profile.getAffiliat()+"\t"+profile.getLang()
                        +"\t"+profile.getYear()+"\t"+profile.getColl_name()+"\t"+profile.getMedlineTA()+"\t"+profile.getKeyword_major()+"\t"+profile.getCoautors();
                line=line.replaceAll("\\{\\}", "null").replaceAll("\\[\\]", "null");
                lines.add(line);
            }
//            profiles.stream().forEach((profile) -> {
//                String line = profile.getPmid()+"\t"+profile.getlName()+" "+profile.getfName_init()+"\t"+profile.getlName()+"\t"+profile.getfName()+"\t"+profile.getfName_init()+"\t"+profile.getAuth_order()+"\t"+profile.getAffiliat()+"\t"+profile.getLang()
//                        +"\t"+profile.getYear()+"\t"+profile.getColl_name()+"\t"+profile.getMedlineTA()+"\t"+profile.getKeyword_major()+"\t"+profile.getCoautors();
//                line=line.replaceAll("\\{\\}", "null").replaceAll("\\[\\]", "null");
//                lines.add(line);
//            });
//            if(!pmid_meshDesc.isEmpty()){
//                pmid_meshDesc.entrySet().stream().map((entry) -> {
//                    String pmid = entry.getKey();
//                    Set<String> value = entry.getValue();
//                    String line = pmid + value;
//                    return line;
//                }).forEach((line) -> {
//                    mesh_lines.add(line);
//                });
//                Files.write(file_mesh, mesh_lines, Charset.forName("UTF-8"));
//            }
            Files.write(file, lines, Charset.forName("UTF-8"));
            
        } catch (IOException ex) {
            Logger.getLogger(OutputWriter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
