/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import author.AuthorCand;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;


/**
 *
 * @author VISHNYAD
 */
public class ValueSplitter {

 
    private Set <AuthorCand> lst_cands;

    public ValueSplitter(File fname, QuerySolr solr) throws SolrServerException, IOException {
       
        splitValues(fname, solr);
    }

    public Set<AuthorCand> getLst_cands() {
        return lst_cands;
    }
    
    
  

    private void splitValues(File fname, QuerySolr solr) throws SolrServerException, FileNotFoundException, IOException{
        String line = "";
        
        String cvsSplitBy = "\t";
        Set <AuthorCand> candidat_lst = new HashSet();
        
       
        BufferedReader br = new BufferedReader(new FileReader(fname));

            while ((line = br.readLine()) != null) {
//what we take from files from ORGS
              
                String[] values = line.split(cvsSplitBy);
                                    String city = "null";
                                    String country ="null";
                                    String year = "null";
                                    String lang = "null";
                                    String jds ="null";
                                    String sts ="null";
                                    String mesh="null";
                                    String order ="null";
                                    String abst ="null";
                                    String title = "null";
                                    String email = "null";
                String pmid = values [0];
                String fName = values [3];
                String init_name = values [2];
                if(values.length>=6) { email = values [6];}
                
                String organ = values [8];
                String coauthors = values [5];
                String org_desc = values [9];
                String org_type = values[10];
                String lname = values [1];
                order = values [4];
                
                
//               Getting Location info
                String tmp_locs = solr.getLocs(pmid,lname,solr.getSolr_locs());
                if(tmp_locs!=null){
                    
                        String [] tmp_city = tmp_locs.split("\t");
                        city = tmp_city[0];
                        country = tmp_city[1];
                  
                }
                
//                  Getting years and language      
                String tmp_lyears = solr.getYearsLang(pmid, solr.getSolr_yl());
                if(tmp_lyears!=null){
                   
                        String[] tmp_yeLang = tmp_lyears.split(";");
                        lang = tmp_yeLang[0];
                        year = tmp_yeLang[1];
                    
                }
   
//                  Getting JDs STs
                String jdst = solr.getJDST(pmid, solr.getSolr_jds());
                if(jdst.length()>4&&!jdst.isEmpty()){
                    String [] tmp_jdst = jdst.split("\t");
//                    System.out.println("JDS from solr "+jdst);
                    jds = tmp_jdst [0];
                    sts = tmp_jdst[1];
                    mesh = tmp_jdst[2];
                    abst = tmp_jdst[3];
                    title = tmp_jdst[4];
                }
                
                
                //Getting CT
                
                String ct = solr.getClinicalT(pmid, solr.getSolr_ct());
              
                AuthorCand candidate = new AuthorCand(lname, fName, init_name, jds, coauthors, pmid, organ, city, country, email, year, lang, sts, org_type, org_desc, ct, mesh, order, abst, title);
                candidat_lst.add(candidate);
            }
          //create pairs, print vectors
          
           
      
        
     this.lst_cands = candidat_lst;
    }
}
