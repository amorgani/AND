/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import java.io.File;
import java.io.IOException;
import org.apache.solr.client.solrj.SolrServerException;
import pairs.PairsChecker;
import solr.connector.QuerySolr;
import vector.MedClassifier;

/**
 *
 * @author VISHNYAD
 */
public class FileReader {

   public void readNS(String fileName,String outDir, MedClassifier classif, QuerySolr solr) throws IOException, SolrServerException, Exception {
        File file = new File(fileName);
        ValueSplitter valueSplitter = new ValueSplitter(file, solr);
        
        PairsChecker pairs_checker = new PairsChecker();
        pairs_checker.doPairs(valueSplitter.getLst_cands(), file, outDir, classif);
       
        
        
           
            

}
}
