/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;
import vector.CreatVector;
import vector.MedClassifier;

/**
 *
 * @author VISHNYAD
 */
public class DirReader {

    public void dirRun(String in, String out, String modelPath)
            throws IOException, SolrServerException, Exception {

        long start = System.currentTimeMillis();
        Path dir = FileSystems.getDefault().getPath(in);
        FileReader read_file = new FileReader();
        MedClassifier clas = new MedClassifier(modelPath);
        QuerySolr solr = new QuerySolr();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            CreatVector vec_creator = new CreatVector();
            
            vec_creator.getVector();
            for (Path path : stream) {
                
               String absoluteFilePath = in + path.getFileName().toString();
               read_file.readNS(absoluteFilePath, out, clas, solr);
            }

            long stop = System.currentTimeMillis();
            System.out.println("Elapsed: " + (stop - start) + " ms");
        }
    }
}
