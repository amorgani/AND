/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import file.DirReader;
import org.apache.solr.client.solrj.SolrServerException;

/**
 *
 * @author vishnyad
 */
public class Start {
    public static void main (String [] args) throws SolrServerException, Exception{
        String dirIN = args[0];
        String dirOUT = args[1];
        String model = args[2];
        DirReader read_dir = new DirReader();
        read_dir.dirRun(dirIN,dirOUT,model);
    
    }
}
