/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsonProfile;

import author.Profile;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.OrderedJSONObject;

/**
 *
 * @author vishnyad
 */
public class JSONprofile {
     public void makeJSON(Map <String, Profile> profiles, String out, String outDir) throws IOException, JSONException {
    FileWriter file = new FileWriter(outDir+out, Boolean.TRUE); 
    file.write("["+System.lineSeparator());
    Iterator<Entry<String,Profile>> iterator = profiles.entrySet().iterator();
		while (iterator.hasNext()) {
                     OrderedJSONObject obj = new OrderedJSONObject();
			Map.Entry<String,Profile> p = (Map.Entry<String,Profile>) iterator.next();
//			System.out.println("Key : " + p.getKey() + " Value :" + p.getValue());
                String tmpJDS =""+ p.getValue().getJds();       
            String jds = tmpJDS.replace("{", "");
            jds = jds.replace("}", "");
            jds = jds.replace(",", "|");
            String tmpSts =""+p.getValue().getSts();
            String sts = tmpSts.replace("{", "");
            sts = sts.replace("}", "");
            sts = sts.replace(",", "|");
//            System.out.println("HERE"+jds);
            obj.put("Last name", p.getValue().getLname());
            obj.put("First name", p.getValue().getFname());
            String affil = p.getValue().getAffil_year().toString();
            affil = affil.replace("[", "");
            affil = affil.replace("]", "");
            obj.put("affil", affil);
            String year = p.getValue().getYears().toString();
            
            year = year.replace("[", "");
            year = year.replace("]", "");
//           System.out.println("YEARS "+year);
            String city = p.getValue().getCity_year().toString();
            city = city.replace("[", "");
            city = city.replace("]", "");
            obj.put("city", city);
            String country =p.getValue().getCountry_year().toString() ;
           country = country.replace("[", "");
           country = country.replace("]", "");
            obj.put("country", country);
            obj.put("Years",year);
////            obj.put("index", p.getKey());
            obj.put("MESH", p.getValue().getMesh());
            obj.put("JDS",jds);
            obj.put("STS",sts);
           
//            String tmp_ord =""; 
//            for(Map.Entry<Integer,Integer> ord: p.getValue().getOrd_fq().entrySet()){
//                tmp_ord=
//            }
//             String tmp_ord = p.getValue().getOrd_fq().toString();
//             tmp_ord=tmp_ord.replace("{", "");
//             tmp_ord=tmp_ord.replace("}", "");
//             obj.put("orders", tmp_ord);
             
            Set <String> tmp_pmids = new HashSet();
            p.getValue().getPmids().stream().map((pmid) -> "https://www.ncbi.nlm.nih.gov/pubmed/"+pmid).forEach((pmid) -> {
                tmp_pmids.add(pmid);
        });
            String pmids = tmp_pmids.toString();
           
            pmids = pmids.replace("[", "");
            pmids = pmids.replace("]", "");
          String abst = p.getValue().getAbst();
          String title = p.getValue().getTitle();
          abst = abst.replace("\"", "");
          abst = abst.replace("\'", "");
          title= title.replace("\"", "");
            obj.put("pmids", pmids);
            obj.put("abst", p.getValue().getAbst());
            obj.put("title", p.getValue().getTitle());
            
            
            
            String lang = p.getValue().getLang().toString();
            lang = lang.replace("[", "");
            lang = lang.replace("]", "");
//            obj.put("lang", lang);
            
            String ct = p.getValue().getCt().toString();
            ct =ct.replace("[", "");
            ct =ct.replace("]", "");
            obj.put("ct", ct);
//            String couautor = p.getValue().getCoautors().toString();
//            couautor=couautor.replace("[", "");
//            couautor=couautor.replace("]", "");
//            obj.put("coautors", couautor);
            
            String email= p.getValue().getEmail_year().toString();
           email=email.replace("[", "");
           email=email.replace("]", "");
           if(email.trim()==null){email=""; }
            obj.put("email", email);
            String tmp_obj = obj.toString().replace("\\/\\/", "/");
            tmp_obj = obj.toString().replace("\\/", "/");
//                    System.out.println(tmp_obj);
            file.write(tmp_obj+System.lineSeparator());
            if(iterator.hasNext()){
                file.write(","+System.lineSeparator());
//                System.out.println("LAST"+jds);
            }
            else {
//                System.out.println("LAST ONE"+email);
                file.write("]"+System.lineSeparator());  
            }
            
          
		}
               
                file.flush();
            
//      for (Map.Entry <String, Profile> p: profiles.entrySet()){
//            JSONObject obj = new JSONObject();
//            String jds = p.getValue().getJds();
//          
//            obj.put("Last name", p.getValue().getLname());
//            obj.put("First name", p.getValue().getFname());
//            obj.put("index", p.getKey());
//            obj.put("MESH", p.getValue().getMesh());
//            obj.put("JDS",jds);
//            obj.put("STS",p.getValue().getSts());
//           
//            String year = p.getValue().getYears().toString();
//            year = year.replace("[", "");
//            year = year.replace("]", "");
//           System.out.println("YEARS "+year);
//            obj.put("Years",year);
////            String tmp_ord =""; 
////            for(Map.Entry<Integer,Integer> ord: p.getValue().getOrd_fq().entrySet()){
////                tmp_ord=
////            }
//             String tmp_ord = p.getValue().getOrd_fq().toString();
//             tmp_ord=tmp_ord.replace("{", "");
//             tmp_ord=tmp_ord.replace("}", "");
//             obj.put("orders", tmp_ord);
//             
//            String city = p.getValue().getCity_year().toString();
//            city = city.replace("[", "");
//            city = city.replace("]", "");
//            obj.put("city", city);
//            


           

        


    }


}
