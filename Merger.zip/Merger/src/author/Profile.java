/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package author;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author vishnyad
 */
public class Profile {
    private String lname;
    private String fname;
    private Set <String> pmids = new HashSet();

    private Set <String> affil_year= new HashSet();
    private Set <String> email_year = new HashSet();
    private List <String> coautors = new ArrayList();
    private Map <String, Integer> jds =new HashMap();
    private Map <String, Integer> sts =new HashMap();
    private String abst ="";
    private String title ="";
    private Set <Integer> years= new HashSet();
    private Set <String> country_year= new HashSet();
    private Set <String> city_year= new HashSet();
    private String mesh= "";
    private String indx;
    private Set <String> lang = new HashSet();
    private Set <String> ct = new HashSet();
    private Map <Integer, Integer> ord_fq = new HashMap(); 

    public Map<Integer, Integer> getOrd_fq() {
        return ord_fq;
    }

    public void setOrd_fq(int o) {
        if(getOrd_fq().containsKey(o)){
            this.ord_fq.put(o, this.ord_fq.get(o)+1);
        }
        else this.ord_fq.put(o, 1);
    }
    
    
    public Set<String> getCt() {
        return ct;
    }

    public void setCt(String ct) {
        if(!ct.isEmpty()){
            this.ct.add(ct);
        }
    }

    public String getAbst() {
        return abst;
    }

    public void setAbst(String abst) {
        if(abst.length()>5){
            String tmp =getAbst()+System.lineSeparator()+ abst;
        this.abst=  tmp;
        }
    }

    public void setTitle(String title) {
          if(title.length()>5){
            String tmp = getTitle()+System.lineSeparator()+title;
            this.title = tmp;
        }
    }

    public String getTitle() {
      
        return title;
    }
    
    
    
    public String getIndx() {
        return indx;
    }

    public void setIndx(String indx) {
        this.indx = indx;
    }

    public Set<String> getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang.add(lang);
    }
    
    
    public void setAffil_year(String affil_year) {
        if (!affil_year.contains("null:")){
            this.affil_year.add(affil_year);
        }
    }

    public void setCity_year(String city_year) {
       if(!city_year.contains("null:")){
            this.city_year.add(city_year);
       }
    }

    public void setCoautors(List<String> coautors) {
        this.coautors.addAll(coautors);
    }


    public void setMesh(String mesh) {
        if(!mesh.contains("null")){
            this.mesh = mesh;
        }
    }

    public void setYears(Integer years) {
        
        this.years.add(years);
    }

    public List<String> getCoautors() {
        return coautors;
    }

    public String getMesh() {
        return mesh;
    }

    public Set<Integer> getYears() {
        return years;
    }




    public void setCountry_year(String country_year) {
        this.country_year.add(country_year);
    }

    public void setEmail_year(String email_year) {
        if(!email_year.contains("null:")){
            this.email_year.add(email_year);
        }
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setJds(Set <String> jds, Map<String,Integer> old) {
    Map <String,Integer>  tmpM = new HashMap();
 
        if(jds.size()>2&&old.size()>=1){
           
         
           for (String item : jds){
               if(old.containsKey(item)){
                  
                   
                   tmpM.put(item, old.get(item)+1);
//                   System.out.println("J+"+item+" count"+old.get(item)+" "+old.size());
               }
               else tmpM.put(item, 1);
           }
             
        }
        else {
            if(jds.size()>2){
               
                jds.stream().forEach((item) -> {
                    tmpM.put(item, 1);
                });
            }
            
            }
     
            this.jds = tmpM;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setPmids(String pmids) {
        
        this.pmids.add(pmids);
    }

    public void setSts(Set <String> sts, Map<String,Integer> old) {
        Map <String,Integer>  tmpM = new HashMap();
        if(sts.size()>5&&old.size()>=1){
           
           for (String item : sts){
               if(old.containsKey(item)){
                   int count = old.get(item);
                   tmpM.put(item, old.get(item)+1);

               }
               else tmpM.put(item, 1);
           }
        }
        else {
            if(sts.size()>1){

                    sts.stream().forEach((item) -> {
                        tmpM.put(item, 1);
                    });
                }
        }
        this.sts=tmpM;
    }



    public Set<String> getAffil_year() {
        return affil_year;
    }

    public Set<String> getEmail_year() {
        return email_year;
    }

    public Set<String> getCity_year() {
        return city_year;
    }


    public Set<String> getCountry_year() {
        return country_year;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public Map<String, Integer> getJds() {
        return jds;
    }

    public Map<String, Integer> getSts() {
        return sts;
    }


    public Set<String> getPmids() {
        return pmids;
    }

  
    
    
}
