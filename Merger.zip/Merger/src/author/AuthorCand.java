/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package author;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 *
 * @author VISHNYAD
 */
public class AuthorCand {
     private String fname;
    private String initial;
    private String lname;
    private Set <String> j_dsc = new HashSet();
    private Set <String> sts_dsc = new HashSet();
    private Double org_type = 0.0;
    private Double org_desc =0.0;
    private String pmid;
    private List<String> coautors;

    private String affil_full;
    private String city;
    private String country;
    private String email;
    private String ct = "";
    private int year;
    private String id;
    private String lang;
    private String mesh = "";
    private int order;
    private String title ="";
    private String abst = "";
 

    public int getOrder() {
        return order;
    }

    public String getTitle() {
        return title;
    }

    public String getAbst() {
        return abst;
    }
    
    
    public void setCt(String ct) {
        this.ct=ct;
    }

    public String getCt() {
        return ct;
    }

    public String getMesh() {
        return mesh;
    }

    public String getLname() {
        return lname;
    }

 
 
    
     public AuthorCand(String lname, String fname, String initial,  String j_dsc,  String coautors,   String pmid, String organ, String city, String country, String email, String year,  String lang, String sts, String org_type, String org_desc, String ct, String mesh, String order, String abst, String title) {
        this.fname = fname;
        this.lname = lname;
        this.initial = initial;
        if(year.contains("null")) this.year = 0;
        else this.year = Integer.parseInt(year);
        this.lang = lang;
        this.mesh = mesh;
       
        this.org_desc = Double.parseDouble(org_desc) ;
        this.org_type=Double.parseDouble(org_type); 
        String [] dsc = j_dsc.split("\\|");  
        for (String dsc1 : dsc) {
            this.j_dsc.add(dsc1.trim());
        }
        String [] tmp_sts_dsc = sts.split("\\|");  
        for (String sc1 : tmp_sts_dsc) {
            this.sts_dsc.add(sc1.trim());
        }
        this.affil_full = organ;
        this.email = email;
        this.city = city;
        this.country = country;
        int tmp = Integer.parseInt(order);
        this.order = tmp;       
        String [] authors = coautors.split(",");
        this.coautors =  Arrays.stream(authors).collect(Collectors.toList());
        this.abst=abst;
        this.title=title;
      
      
        this.pmid=pmid;
    }

    public String getAffil_full() {
        return affil_full;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public String getFname() {
        return fname;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public Set<String> getJ_dsc() {
        return j_dsc;
    }

    public String getPmid() {
        return pmid;
    }

    public int getYear() {
        return year;
    }

    public Set<String> getSts_dsc() {
        return sts_dsc;
    }

    public Double getOrg_type() {
        return org_type;
    }

    public Double getOrg_desc() {
        return org_desc;
    }

    public String getLang() {
        return lang;
    }

    public List<String> getCoautors() {
        return coautors;
    }

    public String getInitial() {
        return initial;
    }


}
