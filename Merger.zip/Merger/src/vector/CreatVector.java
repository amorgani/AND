/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;

/**
 *
 * @author vishnyad
 */
public class CreatVector {
    private FastVector vector;



public Instances getIt(){
  Attribute fname_attr = new Attribute("fname");
        Attribute coautors_attr = new Attribute("coautors");
        Attribute orgs_attr = new Attribute("organisation");
        Attribute jds_attr = new Attribute("jds");
        Attribute sts_attr = new Attribute("sts");
        Attribute email_attr = new Attribute("email");
        
        //email
       // Declare a nominal attribute along with its values
             FastVector fvNominalVal = new FastVector(3);
             fvNominalVal.addElement("-1");
             fvNominalVal.addElement("0");
             fvNominalVal.addElement("1");
             Attribute country_attr = new Attribute("country", fvNominalVal);
             
             FastVector fvNominalVal1 = new FastVector(3);
             fvNominalVal1.addElement("-1");
             fvNominalVal1.addElement("0");
             fvNominalVal1.addElement("1");
             Attribute city_attr = new Attribute("city", fvNominalVal1);
      //
        Attribute lang_attr = new Attribute("lang");
        Attribute years_attr = new Attribute("years");
        Attribute cosDistAB_attr = new Attribute("cosDistAB");
        Attribute init_attr = new Attribute("inits");
         
        FastVector fvClassVal = new FastVector(2);
 fvClassVal.addElement("0");
 fvClassVal.addElement("1");
 Attribute classAttribute = new Attribute("theClass", fvClassVal);
        //
        FastVector fvWekaAttributes = new FastVector(12);
         fvWekaAttributes.addElement(fname_attr);
         fvWekaAttributes.addElement(coautors_attr);
         fvWekaAttributes.addElement(orgs_attr);
         fvWekaAttributes.addElement(jds_attr);
         fvWekaAttributes.addElement(sts_attr);
         fvWekaAttributes.addElement(email_attr);
         fvWekaAttributes.addElement(country_attr);
         fvWekaAttributes.addElement(city_attr);
         fvWekaAttributes.addElement(lang_attr);
         fvWekaAttributes.addElement(years_attr);
         fvWekaAttributes.addElement(cosDistAB_attr);
         fvWekaAttributes.addElement(init_attr);
         fvWekaAttributes.addElement(classAttribute);
         Instances dataset = new Instances("TestInstances", fvWekaAttributes, 12);
 return  dataset;
}

    public CreatVector() {
        
        Attribute fname_attr = new Attribute("fname");
        Attribute coautors_attr = new Attribute("coautors");
        Attribute orgs_attr = new Attribute("organisation");
        Attribute jds_attr = new Attribute("jds");
        Attribute sts_attr = new Attribute("sts");
        Attribute email_attr = new Attribute("email");
        
        //email
       // Declare a nominal attribute along with its values
             FastVector fvNominalVal = new FastVector(3);
             fvNominalVal.addElement("-1");
             fvNominalVal.addElement("0");
             fvNominalVal.addElement("1");
             Attribute country_attr = new Attribute("country", fvNominalVal);
             
             FastVector fvNominalVal1 = new FastVector(3);
             fvNominalVal1.addElement("-1");
             fvNominalVal1.addElement("0");
             fvNominalVal1.addElement("1");
             Attribute city_attr = new Attribute("city", fvNominalVal1);
      //
        Attribute lang_attr = new Attribute("lang");
        Attribute years_attr = new Attribute("years");
        Attribute cosDistAB_attr = new Attribute("cosDistAB");
        Attribute init_attr = new Attribute("inits");
         // Declare the class attribute along with its values
 FastVector fvClassVal = new FastVector(2);
 fvClassVal.addElement("0");
 fvClassVal.addElement("1");
 Attribute classAttribute = new Attribute("theClass", fvClassVal);
        //
        FastVector fvWekaAttributes = new FastVector(12);
         fvWekaAttributes.addElement(fname_attr);
         fvWekaAttributes.addElement(coautors_attr);
         fvWekaAttributes.addElement(orgs_attr);
         fvWekaAttributes.addElement(jds_attr);
         fvWekaAttributes.addElement(sts_attr);
         fvWekaAttributes.addElement(email_attr);
         fvWekaAttributes.addElement(country_attr);
         fvWekaAttributes.addElement(city_attr);
         fvWekaAttributes.addElement(lang_attr);
         fvWekaAttributes.addElement(years_attr);
         fvWekaAttributes.addElement(cosDistAB_attr);
         fvWekaAttributes.addElement(init_attr);
         fvWekaAttributes.addElement(classAttribute);
         this.vector = fvWekaAttributes;
    }
    
    public FastVector getVector() {
        return vector;
    }
    
//    public void defineVectorW (){
        
//         @RELATION DataTable
// @ATTRIBUTE fname  NUMERIC
// @ATTRIBUTE coautors NUMERIC
// @ATTRIBUTE organisation NUMERIC
// @ATTRIBUTE jds NUMERIC
// @ATTRIBUTE sts NUMERIC
// @ATTRIBUTE emails {-2,-1,0,1}
// @ATTRIBUTE countries  {-1,0,1}
// @ATTRIBUTE cities  {-1,0,1}
// @ATTRIBUTE langs NUMERIC
// @ATTRIBUTE years NUMERIC
// @ATTRIBUTE cosDistAB NUMERIC
// @ATTRIBUTE initials  NUMERIC
// @ATTRIBUTE class {0,1}
//@ATTRIBUTE class {0,1}
// @DATA


 
//    }


}
