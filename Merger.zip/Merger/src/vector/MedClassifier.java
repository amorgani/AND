/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vector;

import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

/**
 *
 * @author VISHNYAD
 */
public class MedClassifier {
private  Classifier cls;
private CreatVector vec;

    public Classifier getCls() {
        return cls;
    }

    public CreatVector getVec() {
        return vec;
    }

    public MedClassifier(String modelPath) throws Exception {
         Classifier cls1 = (Classifier) weka.core.SerializationHelper.read(modelPath);
         CreatVector vector = new CreatVector();
         this.vec=vector;
         this.cls= cls1;
    }
    

    public double getResult(String out) throws Exception {
       
        String [] attrs = out.split("\t");
    
        // Create the instance
//        out = names+"\t"+coautors+"\t"+orgsAB+"\t"+jds+"\t"+sts+","+emails+"\t"+countries+"\t"+cities+"\t"+langs+"\t"+years+"\t"+cosDistAB+"\t"+innitials;
          CreatVector vector = new CreatVector();
          
          Instances dataset = new Instances("TestInstances", vector.getVector(), 12);
          dataset.setClassIndex(12);
            Instance iExample = new DenseInstance(12);
            iExample.setDataset(dataset);
        for (int i =0; i<attrs.length; i++){
           
          
//            System.out.println(" Vec"+i+" "+attrs[i]);
         
                double tmp = Double.parseDouble(attrs[i]);
                 iExample.setValue((Attribute)vector.getVector().elementAt(i), tmp);
           
        
        }
        
     
          double index = cls.classifyInstance(iExample);
//          System.out.println("out: "+out+" clas "+index );
            return index;
    }
}

