/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pairs;

import author.AuthorCand;
import author.Profile;
import com.wcohen.ss.JaroWinklerTFIDF;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import jsonProfile.JSONprofile;
import org.apache.commons.lang3.StringUtils;
import vector.MedClassifier;

/**
 *
 * @author vishnyad
 */
public class PairsChecker {

    public void doPairs(Set<AuthorCand> candidate_lst, File inFile, String outputDir, MedClassifier classif) throws IOException, Exception {
        Set<AuthorCand> dbl_canAuthorCands = new HashSet();
        dbl_canAuthorCands.addAll(candidate_lst);
        JaroWinklerTFIDF jaro = new JaroWinklerTFIDF();
        SimilarityComparator comparator = new SimilarityComparator();

        String name = inFile.getName();
      System.out.println("FILE: "+inFile);
        String lname = "";
        //Creating pairs
        Map<String, Profile> profiles = new HashMap();
        Map<String, String> chk_lst = new HashMap();

        int i = 0;
        int count_a=0;
        for (AuthorCand candidate_1 : candidate_lst) {
            count_a++;
            dbl_canAuthorCands.remove(candidate_1);
            String fname_1 = candidate_1.getFname();
            lname =candidate_1.getLname();
            Set<String> jds = candidate_1.getJ_dsc();
            Set<String> sts = candidate_1.getSts_dsc();
            String mesh = candidate_1.getMesh();
            String pmid_1 = candidate_1.getPmid();
//            System.out.println("PMID________________________________________: "+pmid_1);
//            System.out.println("Is there jds? "+jds.size()+" "+pmid_1);
            String affil_1 = candidate_1.getAffil_full();
            String city_1 = candidate_1.getCity();
            String country_1 = candidate_1.getCountry();
            String ct = candidate_1.getCt();
            String lang = candidate_1.getLang();
            String email1 = candidate_1.getEmail();
            String abst_1 = candidate_1.getAbst();
            String title_1 = candidate_1.getTitle();
                    
            int order = candidate_1.getOrder();
            List<String> coautor_1 = candidate_1.getCoautors();
            int year_1 = candidate_1.getYear();
            //PHASE I
            //create index
            //check if authotcand was indexed
            String indx = name + i;
            if (!chk_lst.containsKey(pmid_1 + ":" + fname_1)) {
                chk_lst.put(pmid_1 + ":" + fname_1, indx);
                Profile p1 = new Profile();
                p1.setLname(lname);
                p1.setOrd_fq(order);
                p1.setFname(fname_1);
            
                p1.setPmids(pmid_1);
                p1.setLang(lang);
                p1.setMesh(mesh);
                p1.setJds(jds, p1.getJds());
                p1.setSts(sts, p1.getSts());
                p1.setYears(year_1);
                p1.setAbst(abst_1);
                p1.setTitle(title_1);
                String tmp_email_year = email1+":"+year_1;
                p1.setEmail_year(tmp_email_year);
                if (!affil_1.isEmpty() && !affil_1.contains("null")) {
                    p1.setAffil_year(affil_1 + ":" + year_1);
                }
                if (!city_1.isEmpty() && !city_1.contains("null")) {
                    p1.setCity_year(city_1 + ":" + year_1);
                }
                if (!country_1.isEmpty() && !country_1.contains("null")) {
                    p1.setCountry_year(country_1 + ":" + year_1);
                }
                p1.setCt(ct);
                p1.setCoautors(coautor_1);
                profiles.put(indx, p1);
            }
            //PHASE II
            for (AuthorCand candidate_2 : dbl_canAuthorCands) {
                //extracting infor about the profile 2
                String fname_2 = candidate_2.getFname();
                String pmid_2 = candidate_2.getPmid();
//                System.out.println("PMID2:"+pmid_2);
                String affil_2 = candidate_2.getAffil_full();
                String city_2 = candidate_2.getCity();
                String country_2 = candidate_2.getCountry();
                String ct2 = candidate_2.getCt();
                String lang2 = candidate_2.getLang();
                String abst_2 = candidate_2.getAbst();
                String title_2 = candidate_2.getTitle();
                String email_2 = candidate_2.getEmail();
                
                int ord2 = candidate_2.getOrder();
                Set<String> jds2 = candidate_2.getJ_dsc();
                Set<String> sts2 = candidate_2.getSts_dsc();
                String mesh2 = candidate_2.getMesh();
                List<String> coautor_2 = candidate_2.getCoautors();

                int year_2 = candidate_2.getYear();
//                System.out.println("Comparing " + fname_1 + " " + fname_2);
                Boolean fnameFlag =false;
                     fnameFlag   = comparator.isFNamesEqual(fname_1, fname_2, jaro);
                if (fnameFlag) {
                    Boolean flag = true;

                    //tut proverit s classifier
                    String out = comparator.compareCandidates(flag, candidate_1, candidate_2, jaro);
                    
                    double class_sim = classif.getResult(out);
//                    System.out.println("Names seems to be equal for:"+lname+" fname1:" + fname_1 + " fname2:" + fname_2+" class "+class_sim+" pmid1:"+pmid_1+" pmid2:"+ pmid_2);
                    //if similar then register with the same index
                    if (class_sim == 1.0) {
                        if (chk_lst.containsKey(pmid_1 + ":" + fname_1)) {
                            String indx_tmp = chk_lst.get(pmid_1 + ":" + fname_1);
//                            System.out.println("Belong to the same class " + fname_1 + " " + fname_2);
                            Profile tmp_p = profiles.get(indx_tmp);
//                            System.out.println("PMIDS size in a profile " + tmp_p.getPmids().size());
                            tmp_p.setAffil_year(affil_2+":"+year_2);
                            if (city_2.length() >= 2 && !city_2.contains("null")) {
                                tmp_p.setCity_year(city_2 + ":" + year_2);

                            }
                            if (country_2.length() > 1 && !country_2.contains("null")) {
                                tmp_p.setCountry_year(country_2 + ":" + year_2);
                            }
                            
                            
                            
                            tmp_p.setEmail_year(email_2+":"+year_2);
                            tmp_p.setAbst(abst_2);
                            tmp_p.setTitle(title_2);
                            tmp_p.setYears(year_2);
                            tmp_p.setLname(lname);
                            tmp_p.setCoautors(coautor_2);
                            tmp_p.setCt(ct2);
                            tmp_p.setOrd_fq(ord2);
                            tmp_p.setLang(lang2);
                            tmp_p.setMesh(mesh2);
                            tmp_p.setJds(jds2, tmp_p.getJds());
                            tmp_p.setSts(sts2,tmp_p.getSts());
                            //if name of candidate is longer
                            if (fname_1.length() < fname_2.length()) {
                                tmp_p.setFname(fname_2);
                            }
                      
                            tmp_p.setPmids(pmid_2);
                            chk_lst.put(pmid_2 + ":" + fname_2, indx_tmp);
                            profiles.put(indx_tmp, tmp_p);
                            //then to add
                        }
                    }
                }

            }
            i++;
        }
            System.out.println("COUNTER:"+count_a+" file: "+name);
        //print results in the list NADO OTPECHATAT V FORMAT
//        System.out.println("Printing");
        JSONprofile json = new JSONprofile();
        String tmp_name = name.replaceAll("\\.csv", ".json");
        json.makeJSON(profiles, tmp_name, outputDir);

    }
}
