/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solr.connector;

import java.io.IOException;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;

/**
 *
 * @author vishnyad
 */
public class QuerySolr {
private SolrClient solr_locs ;
private SolrClient solr_jds ;
private SolrClient solr_yl ;
private SolrClient solr_ct ;


    public QuerySolr() {
        this.solr_locs = new HttpSolrClient.Builder("http://rbalv554145.bas.roche.com:8983/solr/locs/").build();
        this.solr_jds = new HttpSolrClient.Builder("http://rbalv554145.bas.roche.com:8983/solr/jdst/").build();
        this.solr_yl = new HttpSolrClient.Builder("http://rbalv554145.bas.roche.com:8983/solr/yl/").build();
        this.solr_ct = new HttpSolrClient.Builder("http://rbalv554145.bas.roche.com:8983/solr/ct/").build();
    }

    public SolrClient getSolr_locs() {
        return solr_locs;
    }

    public SolrClient getSolr_jds() {
        return solr_jds;
    }

    public SolrClient getSolr_yl() {
        return solr_yl;
    }
    
// public void getMeSHwords () throws SolrServerException, IOException{
//       
//    SolrQuery query = new SolrQuery();
//    query.setQuery("25840525");
//    query.addFilterQuery("lname:Smith");
////    query.setFields("pmid");
////    query.setStart(0);    
//    query.set("defType", "edismax");
//    QueryResponse response = getSolr_locs().query(query);
//    SolrDocumentList results = response.getResults();
//      System.out.println(results.size());
//    for (int i = 0; i < results.size(); ++i) {
//      System.out.println(results.get(i).getFieldValue("city"));
//    }
//    }

    public SolrClient getSolr_ct() {
        return solr_ct;
    }
   
 

 public   String getYearsLang (String pmid, SolrClient solr) throws SolrServerException, IOException{
     String res ="";
//        String urlString = "http://rbalv554145.bas.roche.com:8983/solr/yl/";
//    SolrClient solr = new HttpSolrClient.Builder(urlString).build();
         SolrQuery query = new SolrQuery();
//         System.out.println("Checking "+pmid);
         query.setQuery(pmid);
         
         query.set("defType", "edismax");
         QueryResponse response = solr.query(query);
         SolrDocumentList results = response.getResults();
         int year = 0;
         String tmp;
         tmp = results.get(0).getFieldValue("year").toString();
         if (tmp.isEmpty()||tmp.contains("null")){
             res = results.get(0).getFieldValue("lang")+";"+year;
         }
         else {
             res = results.get(0).getFieldValue("lang")+";"+results.get(0).getFieldValue("year");
         }
     
    return res;
    } 
    public   String getLocs (String pmid, String lname, SolrClient solr) throws SolrServerException, IOException{
     String res ="null"+"\t"+"null";
//        String urlString = "http://rbalv554145.bas.roche.com:8983/solr/locs/";
//    SolrClient solr = new HttpSolrClient.Builder(urlString).build()) ;
         SolrQuery query = new SolrQuery();
//                  System.out.println("Checking "+pmid);

         query.setQuery(pmid);
         if(lname.startsWith("-")){
             lname= lname.replace("-", "");
         }
         query.addFilterQuery("lname:"+lname);
         query.set("defType", "edismax");
         QueryResponse response = solr.query(query);
         SolrDocumentList results = response.getResults();
         
         if(!results.isEmpty()){
             res = results.get(0).getFieldValue("city")+"\t"+results.get(0).getFieldValue("country");
         } 
    return res;
    } 
    
    
   public String getJDST (String pmid, SolrClient solr) throws SolrServerException, IOException{
     String res ="";
//        String urlString = "http://rbalv554145.bas.roche.com:8983/solr/jdst/";
//     SolrClient solr = new HttpSolrClient.Builder(urlString).build();
         SolrQuery query = new SolrQuery();
//                  System.out.println("Checking "+pmid);

         query.setQuery(pmid);
         query.set("defType", "edismax");
         QueryResponse response = solr.query(query);
         SolrDocumentList results = response.getResults();
////         System.out.println("PMID "+pmid+" Results"+results);
         if(!results.isEmpty()){
             res = results.get(0).getFieldValue("jd")+"\t"+results.get(0).getFieldValue("st")+"\t"+results.get(0).getFieldValue("mesh")+"\t"+results.get(0).getFieldValue("abst")+"\t"+results.get(0).getFieldValue("title");
             res= res.replace("null;", "");
         
         }
     
    return res;
    } 
   
   public String getClinicalT (String pmid, SolrClient solr) throws SolrServerException, IOException{
   String res ="";
//        String urlString = "http://rbalv554145.bas.roche.com:8983/solr/ct/";
//     SolrClient solr = new HttpSolrClient.Builder(urlString).build();
         SolrQuery query = new SolrQuery();
//                  System.out.println("Checking "+pmid);

         query.setQuery(pmid);
         
         query.set("defType", "edismax");
         QueryResponse response = solr.query(query);
         SolrDocumentList results = response.getResults();
         if(!results.isEmpty()){
             res = results.get(0).getFieldValue("ClinicalTrialID")+"";
         }
     
    return res;
   }

   
}
