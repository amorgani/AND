/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package split;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author vishnyad
 */
public class NamespaceChecker {
    public void checkName(String filename, String dirOut) throws FileNotFoundException, IOException{
       BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        FileWriter fw;
        BufferedWriter bw;
        PrintWriter out ;
        while ((line = br.readLine()) != null) {
         String [] profile_flds;
           profile_flds = line.split("\t");
           String init = profile_flds[3];
//           String init = profile_flds[8];
//            System.out.println("TEST  "+init);
//           String init = profile_flds[6];
           if(init.length()>1){
            init = init.substring(0,1);
           }
          String fname_out= profile_flds[1];
          
          fname_out = replaceUmlaut(fname_out);
//          String fname_out= profile_flds[7];
          fname_out=fname_out.replaceAll("[-'\\s/]", "");
          String outfile = fname_out+"_"+init;
          outfile=outfile.toLowerCase(Locale.ENGLISH);
//          String fname_out= profile_flds[5];
          outfile = dirOut+outfile+".csv";
          
       
       //  System.out.println("name: "+outfile);
        
       
              fw = new FileWriter(outfile, true);
              bw = new BufferedWriter(fw);
              out = new PrintWriter(bw);
              out.write(line+"\n");
              out.close();
         
         
        }
       
    }
    
    private  String replaceUmlaut(String input) {
     
//    System.out.println("Before :"+input);
     //replace all lower Umlauts
     String output = input.replace("ü", "ue")
                          .replace("ö", "oe")
                          .replace("ä", "ae")
                          .replace("ß", "ss");

     //first replace all capital umlaute in a non-capitalized context (e.g. Übung)
     output = output.replace("Ü(?=[a-zäöüß ])", "Ue")
                    .replace("Ö(?=[a-zäöüß ])", "Oe")
                    .replace("Ä(?=[a-zäöüß ])", "Ae");

     //now replace all the other capital umlaute
    
     output =StringUtils.stripAccents(output);
//    System.out.println("After :"+output);
     return output;
 }
//    public static void main (String[] args){
//       String out = replaceUmlaut("übüng");
//        System.out.println(out);
//    }
}
