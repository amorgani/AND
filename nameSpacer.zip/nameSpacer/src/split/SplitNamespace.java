/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package split;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author vishnyad
 */
public class SplitNamespace {
     public void inputDir(String in, String out) throws IOException, ParserConfigurationException, SAXException {
 
   File directory = new File(in);
//   File directory = new File("C:\\Users\\vishnyad\\MEDLINE2016\\Joined\\");
//   File directory = new File("U:\\My Documents\\virtualDisk\\2014\\SONGCollect\\train\\");
   
   System.out.println("# of files in a directory: "+directory.list().length);
   NamespaceChecker namespaces = new NamespaceChecker();
  
   for(File file : directory.listFiles()){
           String filenameInput=file.getAbsolutePath();
           System.out.println("Reading file: "+filenameInput);
            namespaces.checkName(filenameInput, out);
//            namespaces.checkName(filenameInput, "C:\\Users\\vishnyad\\MEDLINE2016\\names\\");
           
           System.out.println("Done with file: "+filenameInput);

         }
     }
     
     public static void main(String [] args) throws IOException, ParserConfigurationException, SAXException{
         String in = args [0];
         String out =args [1];
         SplitNamespace sn = new SplitNamespace();
         sn.inputDir(in, out);
     }
}
