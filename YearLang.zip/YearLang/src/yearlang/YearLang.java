/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yearlang;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author VISHNYAD
 */
public class YearLang {

    public void readDir(String in, String out) throws IOException{
        File directory = new File(in);
        System.out.println("# of files in a directory: "+directory.list().length);
    for(File file : directory.listFiles()){
            Map<String, Model> bagOfPmids = getUniqueAbstract(file);
            System.out.println("file: "+file.getName());
            printOut(file, bagOfPmids, out);
    }
    }

    private Map <String, Model> getUniqueAbstract(File file) throws IOException{
        BufferedReader br;
       
            br = new BufferedReader(new FileReader(file));
           
                String x;
                Map <String, Model> bagOfPmids = new HashMap();
                while ( (x = br.readLine()) != null ) {
                    Model yearLang = new Model();
                    // printing out each line in the file
                    String [] field = x.split("\t");
//                    if(field.length!=22){
//                        System.out.println("Field[]: "+field.length+" file"+ file.getName());
//                        System.out.println("Line: "+x);
//                    }
                    
                    if(!bagOfPmids.containsKey(field[0])){
                        yearLang.setLang(field[6]);
                        yearLang.setYear(field[7]);
                        yearLang.setLname(field[1]);
                        bagOfPmids.put(field[0]+"\t"+field[1], yearLang);
                    
                    }
                } 
                    System.out.println("Size of bag:"+bagOfPmids.size());
                    
        return bagOfPmids;
    }
    
    private void printOut(File file, Map<String, Model> bag, String outDir) throws FileNotFoundException, IOException{
        FileWriter fw ;
     BufferedWriter         bw;
         PrintWriter     out ;
              fw = new FileWriter(outDir+file.getName(), true);
              bw = new BufferedWriter(fw);
              out = new PrintWriter(bw);
              for(Map.Entry <String,Model> entry:bag.entrySet()){
              
                  out.println(entry.getKey()+"\t"+entry.getValue().getLang()+"\t"+entry.getValue().getYear());
              }
            
//			System.out.println("Key : " + entry.getKey() );
       
        out.close();
       
    }
    
    public static void main (String[] args){
        String in = "C:\\Users\\vishnyad\\Desktop\\crowdSource\\new\\years\\";
//        String in = args[0];
        String out="C:\\Users\\vishnyad\\Desktop\\crowdSource\\new\\1804_years";
//        String out=args[1];
        YearLang catcher = new YearLang();
        try {
            catcher.readDir(in, out);
        } catch (IOException ex) {
            Logger.getLogger(YearLang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
