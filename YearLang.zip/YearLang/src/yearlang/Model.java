/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yearlang;

/**
 *
 * @author VISHNYAD
 */
public class Model {
    private String lang;
    private String year;
    private String lname;

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }
    
    
    
    public String getLang() {
        return lang;
    }

    public String getYear() {
        return year;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public void setYear(String year) {
        this.year = year;
    }
    
    
    
}
