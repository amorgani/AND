/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stanford.ner.seven;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author VISHNYAD
 */
public class LocOrganisationModel {
  private Set <String> locations = new HashSet();
  private Set <String> organs = new HashSet();

    public void setLocations(Set<String> locations) {
        this.locations = locations;
    }

    public Set<String> getLocations() {
        return locations;
    }

    public Set<String> getOrgans() {
        return organs;
    }

    public void setOrgans(Set<String> organs) {
        this.organs = organs;
    }

   
}
