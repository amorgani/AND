/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stanford.ner.seven;

import edu.stanford.nlp.ie.crf.CRFClassifier;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

/**
 *
 * @author VISHNYAD
 */
public class LctOrgSearcher {
    private String serializedClassifier;
    private CRFClassifier<CoreLabel> classifier ;

    public LctOrgSearcher(String pathMode) {
        this.serializedClassifier =  pathMode;
        this.classifier = CRFClassifier.getClassifierNoExceptions(serializedClassifier);
    }
    
    public  LinkedHashMap<String, LinkedHashSet<String>> identifyNER(String text) {
        LinkedHashMap<String, LinkedHashSet<String>> map = new <String, LinkedHashSet<String>>LinkedHashMap();
     
        List<List<CoreLabel>> classify = classifier.classify(text);
        classify.stream().forEach((List<CoreLabel> coreLabels) -> {
            coreLabels.stream().forEach((CoreLabel coreLabel) -> {
                String word = coreLabel.word();
                String category = coreLabel.get(CoreAnnotations.AnswerAnnotation.class);
                if (!"O".equals(category)) {
                    if (map.containsKey(category)) {
                        // key is already their just insert in arraylist
                        map.get(category).add(word);
                    } else {
                        LinkedHashSet<String> temp = new LinkedHashSet<>();
                        temp.add(word);
                        map.put(category, temp);
                    }
//                    System.out.println(word + ":" + category);
                   
                }
            });
        });
                         
        return map;
    }
    
   
//     public static void main(String args[])
// {
// String content="[Hefei National Laboratory for Physics Sciences at Microscale and Department of Modern Physics, University of Science and Technology of China, Hefei 230026, China and Synergetic Innovation Center of Quantum Information and Quantum Physics, University of Science and Technology of China, Hefei, Anhui 230026, China.;]".replace("[^a-zA-Z0-9]", ",");
// String [] p = content.split(",");
//            LctOrgSearcher lct = new LctOrgSearcher();
//        for (String p1 : p) {
//            String tmp =lct.identifyNER(p1).toString();
//           System.out.println("Hi "+tmp.replace("[^a-zA-Z0-9&=]", "")); 
//        }
//
// 
// }
}
