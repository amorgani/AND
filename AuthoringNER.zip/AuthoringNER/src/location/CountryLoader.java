/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author vishnyad
 */
public class CountryLoader {
     
    
    public Map <String, String> getCountryEntities(String csvFilepath) throws FileNotFoundException, IOException {
       
        String cvsSplitBy = ";";
       
        File file = new File(csvFilepath);
//        String tmp_write = dirpath+"location_"+file.getName();
//        Path fileWrite = Paths.get(tmp_write);
        Map<String,String> towrite = new HashMap<>();
       BufferedReader br ;
            br = new BufferedReader(new FileReader(file));
        
           
           for (String linecsv = br.readLine(); linecsv != null; linecsv = br.readLine()) {

              
                // use tab as separator
            
              
                    String[] csv_fields = linecsv.split(cvsSplitBy);
                 
                    //work with lines of the csv files
                    String name = csv_fields[0];
                   
                    String country_code = csv_fields[1];
                   
                    
                  
                    //output selected fields as following
                   
                    towrite.put(name,country_code);
                    
                    
                        
                

            }
            
           return towrite;
    }
}
