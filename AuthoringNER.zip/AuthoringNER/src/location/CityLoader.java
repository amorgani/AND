/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vishnyad
 */
public class CityLoader {
     public List <String> getDictEntities(String csvFilepath) throws FileNotFoundException, IOException {
       
        String cvsSplitBy = "\t";
       
        File file = new File(csvFilepath);
//        String tmp_write = dirpath+"location_"+file.getName();
//        Path fileWrite = Paths.get(tmp_write);
        List<String> towrite = new ArrayList<>();
       BufferedReader br ;
            br = new BufferedReader(new FileReader(file));
        
           
           for (String linecsv = br.readLine(); linecsv != null; linecsv = br.readLine()) {

              
                // use tab as separator
            
              
                    String[] csv_fields = linecsv.split(cvsSplitBy);
                 
                    //work with lines of the csv files
                    String off_name = csv_fields[1];
                    String sec_off_name = csv_fields[2];
                    String synonyms = csv_fields[3];
                    String country_code = csv_fields[8];
                    String zone = csv_fields[14];
                    
                  
                    //output selected fields as following
                    String info = off_name+"\t"+sec_off_name+"\t"+synonyms+"\t"+country_code+"\t"+zone;
                    towrite.add(info);
                    
                    
                        
                

            }
            
           return towrite;
    }
}
