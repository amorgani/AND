/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author vishnyad
 */
public class LocationNormaliser {

    private List<String> cityVocab;
    private Map<String, String> countryCodes;
    private Pattern p;
    private Matcher m;

    public LocationNormaliser(String cityCsv, String countryCsv) {
        try {
            this.cityVocab = new CityLoader().getDictEntities(cityCsv);
            this.countryCodes = new CountryLoader().getCountryEntities(countryCsv);
            System.out.println("Country list size: " + countryCodes.size());
        } catch (IOException ex) {
            Logger.getLogger(LocationNormaliser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//read the file containing raw data about LOCATION and ORGANIZATION and process them
    public void readOrgLocfile(String pathCsv, String dirpath, int col) throws IOException {
        File file = new File(pathCsv);
        String tmp_write = dirpath + "location_" + file.getName();
        Path fileWrite = Paths.get(tmp_write);
        BufferedReader br;
        br = new BufferedReader(new FileReader(pathCsv));
        String cvsSplitBy = "\t";
        List<String> allback = new ArrayList();
        for (String linecsv = br.readLine(); linecsv != null; linecsv = br.readLine()) {
            String country_code = "null";
            String towrite;

            String res = null+"\t"+null;
            //pmid, fullName, firstName, location, organisation, value, value

            String[] csv_fields = linecsv.split(cvsSplitBy);
            String location = csv_fields[col];
            //work with location since it can be null or
            if (!location.contains("null")) {
                if (location.contains(",")) {

                    String[] tmp_locs = location.split(",");
                    boolean flag_country_code = false;
                    Set<String> cc = new HashSet();
                    Set<String> citi = new HashSet();
                    for (String tmp_loc : tmp_locs) {
                        //check if it is a country name
                        String loc_entity = tmp_loc.trim();
                        if (countryCodes.containsKey(loc_entity)) {
                            country_code = countryCodes.get(loc_entity);
                            flag_country_code = true;
                            cc.add(country_code);
                        } else {
                            String tmp = lookAtDicts(loc_entity);
                            if(tmp==null){ res = "null" + "\t"+ "null";}
                            else {
                                
                                String[] returned_cc = tmp.split("\t");
                                System.out.print("HI " + Arrays.toString(returned_cc));
                                if (!flag_country_code) {
                                    citi.add(returned_cc[0]);
                                    cc.add(returned_cc[1]);
                                } else {
                                    citi.add(returned_cc[0]);
                                }
                            }
                            
                            
                            
                        }
                    }

                    //if we have many different cities and countries we will write them
                    res = citi + "\t" + cc;
                    res = res.replace("[", "");
                    res = res.replace("]", "");

                } //if it is one token then we have to figure out if it is a city or a country
                else //first we check countries, it is faster
                if (countryCodes.containsKey(location.trim())) {
                    country_code = countryCodes.get(location.trim());
                    res = "null" + "\t" + country_code;
                } //if the token was not a country, we look in the cities
                else {
                    String tmp = lookAtDicts(location.trim());
                    if(tmp==null){ res = "null" + "\t"+ "null";}
                    else {
                        res = tmp;
                    }
                    

                }
            }
            towrite = csv_fields[0] + "\t" + csv_fields[1] + "\t" + csv_fields[2] + "\t" + csv_fields[3] + "\t" + res;
//            System.out.println(towrite);
            allback.add(towrite);
        }
        Files.write(fileWrite, allback, Charset.forName("UTF-8"));

    }

    private String lookAtDicts(String location) {
        String city = null;
        
        String res = null;
        //We have to check how many times this name is met in different countries
        List<String> n_cities = new ArrayList();
        List<String> s_cities = new ArrayList();

        for (String entity : cityVocab) {
            String[] fields_city = entity.split("\t");
            String of_name = fields_city[0].trim();
           
            String sof_name = fields_city[1].trim();
            String synonyms = fields_city[2];
            String code = fields_city[3];
           
            String[] syns = synonyms.split(",");
            Set<String> mySet = new HashSet(Arrays.asList(syns));
//            System.out.println("Cities: "+of_name+"\t"+sof_name+"\t"+mySet+"\t"+code );
//                                   String zone = fields_city[4];
            boolean flag_o = false;
            boolean flag_s = false;
            if (of_name.equalsIgnoreCase(location)) {
                city = sof_name;
               
                n_cities.add(sof_name);
                flag_o = true;
                

            } 
            if (!flag_o&&sof_name.equalsIgnoreCase(location)) {
                city = sof_name;
                s_cities.add(city);
            
                flag_s = true;
            } 
            if (!flag_o && !flag_s) {
                    if(mySet.contains(location)){
                        res = of_name + "\t" + code;
                        System.out.println("Result: "+res);
                    }
//                //                p = Pattern.compile("\\w+" + location + "\\w+");
//                p = Pattern.compile("[^\\s\\-]\\t{0,1}\\,{0,1}\\b" + location + "\\b[^\\s]\\t{0,1}");
//                m = p.matcher(synonyms);
//        
//                if (m.find()) {
//                    city = location ;
//                    country_code = code;
//                   
//                        res = city + "\t" + country_code;
//                        System.out.println("Check here "+city+" "+country_code+" ");
//                    
//                }
            }
        }
        if (n_cities.size() > 1 ) {
            res = city + "\t" + "null";
        }
        
        return res;
    }

}
