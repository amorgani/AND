/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pattern.email;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;
import stanford.ner.seven.LctOrgSearcher;
import stanford.ner.seven.LocOrganisationModel;

/**
 *
 * @author VISHNYAD
 */
public class LocOrgSearcher {
  
 private LctOrgSearcher lct;

    public LocOrgSearcher(String pathModel) {
        this.lct=  new LctOrgSearcher(pathModel);
    }
 
  private LocOrganisationModel writeEntities (String text, LctOrgSearcher searcher){
    String content=text.replace("[^a-zA-Z0-9]", ",");
    String [] p = content.split(",");
    
    LocOrganisationModel model1 = new LocOrganisationModel();
 
   Set <String> tmp_orgs = new HashSet();
    Set<String> tmp_locs = new HashSet();
    
        for (String p1 : p) {
      
            boolean flag_org=false;
          
           String result = (searcher.identifyNER(p1).toString()); 
            result = result.replaceAll("[^\\p{L}a-zA-Z0-9\\s'&=\\-]", "");
            String [] type_text = result.split("=");
          if(type_text[0].contains("ORGANIZATION")){
                flag_org=true;
                
                if(flag_org==true){
                    String org = type_text[1];
//                    org = org.replaceAll("[^\\p{L}a-zA-Z0-9\\s]", "");
                        tmp_orgs.add(org);
                        System.out.println("Organisation: "+org);
                    }
                
                }
            if(type_text[0].contains("LOCATION")){
                    flag_org=false;
                    if(flag_org==false){
                        String loc = type_text[1];
//                          loc =loc.replaceAll("[^\\p{L}a-zA-Z0-9\\s]", "");
                        tmp_locs.add(loc);
//                        System.out.println("Location: "+loc );
                    }

                }
            }
        model1.setLocations(tmp_locs);
        model1.setOrgans(tmp_orgs);
        return model1;
        }
      public void getLocsOrgs(String csvFilepath, String dirpath, String pathModel, int col) throws FileNotFoundException, IOException {
        LocOrgSearcher locOrgLook = new LocOrgSearcher(pathModel);
        String cvsSplitBy = "\t";
       
        File file = new File(csvFilepath);
        String tmp_write = dirpath+"orgs_"+file.getName();
       
      
          BufferedReader br = new BufferedReader(new FileReader(file));
         EmailSearcher emailFinder = new EmailSearcher();
         String email="null";
         PrintWriter out = new PrintWriter(tmp_write);
           System.out.println("The file: "+tmp_write+" is processing");
           for (String linecsv = br.readLine(); linecsv != null; linecsv = br.readLine()) {
           

           
                    String[] csv_fields = linecsv.split(cvsSplitBy);
                    LocOrganisationModel tmp;
                    tmp = null;
                    email= emailFinder.getEmails(csv_fields[col]);
                    tmp =   locOrgLook.writeEntities(csv_fields[col], lct);
                    int org_type=0;
                    double res_type=0;
                    
                    String organisation;
                 
                    
                    
                    if(tmp.getOrgans()!=null){
                         Set <String> organs = tmp.getOrgans();
                           organisation =""+organs;
                             if(organisation.contains("Univers"))org_type =org_type+ 1;
                             if(organisation.contains("Institu"))org_type=org_type+2;
                             if(organisation.contains("College"))org_type=org_type+3;
                             if(organisation.contains("Labor"))org_type=org_type+4;
                             if(organisation.contains("Organization")||organisation.contains("Organisation"))org_type=org_type+5;
                             if(organisation.contains("Ministry"))org_type=org_type+6;
                             if(organisation.contains("Center")||organisation.contains("Centr"))org_type=org_type+7;
                             if(organisation.contains("Department"))org_type=org_type+8;
                             if(organisation.contains("Hospital"))org_type=org_type+9;
                             if(organisation.contains("School"))org_type=org_type+10;
                             if(organisation.contains("Biolog"))res_type=1;
                             if(organisation.contains("Chemist"))res_type=2;
                             if(organisation.contains("Pediatric"))res_type=3;
                             if(organisation.contains("Surgery"))res_type=3;
                             if(organisation.contains("Medicine")||organisation.contains("Medical"))res_type=3;
                             if(organisation.contains("Genetic"))res_type=4;
                             if(organisation.contains("Infect"))res_type=5;
                             if(organisation.contains("Agricult"))res_type=6;
                             if(organisation.contains("Entomolog"))res_type=7;
                             if(organisation.contains("Biotech"))res_type=8;
                             if(organisation.contains("Neurolog"))res_type=9;
                             if(organisation.contains("Psychol"))res_type=10;
                             if(organisation.contains("Pharma"))res_type=11;
                             if(organisation.contains("Toxic"))res_type=res_type+1.1;
                             if(organisation.contains("Cancer"))res_type=res_type+2.1;
                             if(organisation.contains("Cardiol"))res_type=12;
                             if(organisation.contains("Dentist"))res_type=res_type+13.5;
                             if(organisation.contains("Nutrition"))res_type=13;
                             if(organisation.contains("Health"))res_type=res_type+0.6;
                             if(organisation.contains("Disease"))res_type=res_type+0.11;
                             
                             
                             
                             
                             
                    }
                    else organisation = "null";
                        
                 
//                     System.out.println(csv_fields[0]+"number fields: "+csv_fields.length);
                     
                     String info = csv_fields[0]+"\t"+csv_fields[1]+"\t"+csv_fields[2]+"\t"+csv_fields[3]+"\t"+csv_fields[4]+"\t"+csv_fields[5]+"\t"+email+"\t"+csv_fields[col]
                             +"\t"+organisation+"\t"+res_type+"\t"+org_type;
                     info = info.replace("[", "");
                     info = info.replace("]", "");
                     info = info.replace("ORGANIZATION", "");
                     info = info.replace("LOCATION", "");
                     info = info.replace("DATE", "");
                     info = info.replace("PERSON", "");
            //add printer
                out.println(info);
//                                towrite.add(info);
           
            }
           out.flush();
            
                    
//                     Files.write("wer", list, Charset.forName("UTF-8"));
                 
       
     
    }
}
