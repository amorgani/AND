package pattern.email;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author VISHNYAD
 */
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailSearcher {
	private final Pattern pattern = Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}");
        // Read affiliation find valid mail addresses 
   private List <String> findEmail(String affiliation) throws IOException {
     
       List <String> email =new ArrayList();
        // Simple expression to find a valid e-mail address in a file
        
   
       
            Matcher matcher = pattern.matcher(affiliation.toUpperCase());
            if (matcher.find())  {
                String tmp=matcher.group();
                   email.add(tmp);
                   
            }
               
            
        
     
        return email;
  }
    public String getEmails(String affil) throws FileNotFoundException, IOException {
        EmailSearcher emaiLook = new EmailSearcher();
       
        
          

                String tmp_email ="null";
                // use tab as separator
               
               
                
                    List <String> tmp =null;
                    tmp = emaiLook.findEmail(affil);
                    
                    
                    if (!tmp.isEmpty()){
                        if(tmp.size()>0){
                              
                                tmp_email = ""+emaiLook.findEmail(affil);
                                tmp_email=tmp_email.replace("[","");
                                tmp_email=tmp_email.replace("]","");
                                tmp_email=tmp_email.replace(">", "");
                                tmp_email=tmp_email.replace("<", "");
                                        
                               
                        }
                      
                    }
                    else{
//                        System.out.println("We have null");
                        tmp_email="null";
                    }
                    
                
return tmp_email;
    }
}
