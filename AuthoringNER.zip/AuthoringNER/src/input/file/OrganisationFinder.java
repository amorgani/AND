/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.file;

import java.io.File;
import java.io.IOException;

import pattern.email.LocOrgSearcher;

/**
 *
 * @author VISHNYAD
 */
public class OrganisationFinder {


    public void fileFound(String pathTofiles, String outDir, String modelPath, int col) throws IOException {
    
          
            File directory = new File(pathTofiles);
            LocOrgSearcher
              locorg = new LocOrgSearcher(modelPath);
            for (File file : directory.listFiles()) {
                String filename = file.getAbsolutePath();
                locorg.getLocsOrgs(filename, outDir, modelPath,  col);

            }

          

    }



   

   
}