/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.file;

import java.io.IOException;

/**
 *
 * @author VISHNYAD
 */
public class Start {
     public static void main(String args[]) throws IOException {
            String type = args [0];
            if(type.equalsIgnoreCase("org")){
                String in = args [1].replace("*", ""); //U:\\My Documents\\virtualDisk\\2014\\medOut\\
                String out = args [2].replace("*", ""); //U:\\My Documents\\virtualDisk\\2014\\orgloc\\
                String model = args[3].replace("*", "");
                int col = Integer.parseInt(args[4]);
                OrganisationFinder runner = new OrganisationFinder();
                runner.fileFound(in, out, model, col);
            
            }
            else if (type.equalsIgnoreCase("loc")){
                    String cities1500 =args[0] ;
                    String country_cd = args[1];
                    String in = args[2];
                    String out=args[3];
                    int col = Integer.parseInt(args[4]);
                        LocationFinder runner = new LocationFinder(cities1500,country_cd, out,col);
                        runner.fileFound(in);
                        runner.run();
                        }
   
//            runner.fileFound("U:\\My Documents\\virtualDisk\\MEDLINEarch\\MdlGzipOut\\");
           
    }
}
