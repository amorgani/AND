/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input.file;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import location.LocationNormaliser;
import org.apache.log4j.Logger;

/**
 *
 * @author vishnyad
 */
public class LocationFinder implements FileListReader{
    
    private LinkedBlockingQueue<String> files;
    private AtomicBoolean done = new AtomicBoolean(false);
    private Logger logger;
    private String cityCsv;
    private String countryCsv;
    private String outDir;
 
    private int col;
    public LocationFinder(String cityCsv,String countryCsv,  String outDir, int col ) {
        this.logger = Logger.getLogger(LocationFinder.class);
        this.cityCsv = cityCsv;
        this.countryCsv=countryCsv;
        this.col=col;
        this.outDir=outDir;
      
    }

    public String getOutDir() {
        return outDir;
    }

    public int getCol() {
        return col;
    }

    public String getCityCsv() {
        return cityCsv;
    }

    public String getCountryCsv() {
        return countryCsv;
    }

//      private List <MDLProfile> profiles = new ArrayList ();
//    public List<MDLProfile> getProfiles() {
//        return profiles;
//    }
    @Override
    public void fileFound(String pathTofiles) {
        try {
            files = new LinkedBlockingQueue(1000);
            File directory = new File(pathTofiles);
            logger.trace("# of files in a directory: " + directory.listFiles().length);
            for (File file : directory.listFiles()) {
                files.put(file.getAbsolutePath());

            }

            files.put("mmm"); //this last entry tells the worker threads to stop
            logger.trace("Now is finished to put files");
        } catch (InterruptedException ex) {
            logger.error("Sorry, something wrong in fileFound!", ex);
        }

    }


//
//    public static void main(String args[]) {
//        String cities1500 =args[0] ;
//        String country_cd = args[1];
//        String in = args[2];
//        String out=args[3];
//        int col = Integer.parseInt(args[4]);
//            LocationFinder runner = new LocationFinder(cities1500,country_cd, out,col);
//            runner.fileFound(in);
//            runner.run();
//    }

    @Override
    public void run() {
        
        
        while (!done.get()) {

            try {
                String filename = files.take();

                if (!filename.contentEquals("mmm")) {

//               profiles.addAll( gzipreader.readAuthors(filename)); //create list of all authors from the file
                   LocationNormaliser normal = new LocationNormaliser(getCityCsv(),getCountryCsv());
                   normal.readOrgLocfile(filename, getOutDir(), getCol());
                   

                } else {
                    done.set(true);//signal to the other threads that we found the final element.
                }
            } catch (InterruptedException ex) {
                logger.error("Sorry, something wrong in fileFound!", ex);
            } catch (IOException ex) {
                java.util.logging.Logger.getLogger(LocationFinder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
     
}
