/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler;

import comparator.PairsCreator;
import comparator.SongPairsCreator;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;
import stat.NameSpacer;

/**
 *
 * @author VISHNYAD
 */
public class NameSpacesReader {
   
   
    
    
       public void readNS(String dir, String modelOut, String jdstFile, String lyFile, String locFile) throws IOException {
        File directory = new File(dir);
        System.out.println("#" + directory.list().length + " of files in a directory: " + directory.getName());
        DirReader reader = new DirReader();
        PairsCreator pairs_creator = new PairsCreator();
        Map <String, String> jdst = reader.getMapJDST(jdstFile);
        Map <String, String> langyear = new HashMap();
        langyear.putAll(reader.getMapLangYear(lyFile));
                
        System.out.println("Year Lang "+langyear.size());
        Map <String, String> locs = reader.getMapLoc(locFile);
        
        for (File file : directory.listFiles()) {
           
            
            ValueSplitter valueSplitter = new ValueSplitter(file, jdst, locs, langyear);
            //create pairs and print
            pairs_creator.doPairs(valueSplitter.getLst_cands(), modelOut);
        }
    }
       public void readNSsong(String dir, String out, NameSpacer ns, QuerySolr solr) throws IOException, SolrServerException{
           File directory = new File(dir);
           System.out.println("#" + directory.list().length + " of files in a directory: " + directory.getName());
        
            SongPairsCreator pairs_creator = new SongPairsCreator();
        for (File file : directory.listFiles()) {
           System.out.println("now is processing.. "+file.getName());
            
            ValueSplitter valueSplitter = new ValueSplitter(file, solr);
            //create pairs and print
          
            pairs_creator.doPairs(valueSplitter.getLst_cands(),out, ns);
        }
       }
}
