/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author VISHNYAD
 */
public class Modeler {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ns = args[0];
        String out = args[1];
        String jds = args [2];
        String langyear = args [3];
        String locs = args [4];
        NameSpacesReader nsr = new NameSpacesReader();
        try {
            nsr.readNS(ns, out, jds, langyear, locs);
        } catch (IOException ex) {
            Logger.getLogger(Modeler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
