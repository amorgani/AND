/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author VISHNYAD
 */


public class PairsReader {
    private List <String> lst = new ArrayList();

    public List<String> getLst() {
        return lst;
    }
    
    
    public void readPairs(String pairsFile){
        
       
        BufferedReader br = null;
        String line = "";
        
        
        List <String> list_lines = new ArrayList();
        try {

            br = new BufferedReader(new FileReader(pairsFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
              list_lines.add(line);

            }

        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                }
            }
        }
      this.lst = list_lines;
    }
  
}
