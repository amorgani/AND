/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeler.row.AuthorCand;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;

/**
 *
 * @author VISHNYAD
 */
public class ValueSplitter {

 
    private Set <AuthorCand> lst_cands;

    public ValueSplitter(File fname, Map <String,String> jdst, Map <String,String> locs, Map <String,String> lyears) {
       
        splitValues(fname, jdst, locs, lyears);
    }

    public ValueSplitter(File fname, QuerySolr solr) throws IOException, SolrServerException {
        
            System.out.println("Splitting");
            splitValuesSong(fname, solr);
        
    }
 
    public Set<AuthorCand> getLst_cands() {
        return lst_cands;
    }
    
    
  

    private void splitValues(File fname, Map <String,String> jdst, Map <String,String> locs, Map <String,String> lyears ){
        String line = "";
        
        String cvsSplitBy = "\t";
        Set <AuthorCand> candidat_lst = new HashSet();
        Map <String, String> pmid_city_country = new HashMap();
       
        try (BufferedReader br = new BufferedReader(new FileReader(fname))) {

            while ((line = br.readLine()) != null) {

              
                String[] values = line.split(cvsSplitBy);
                                    String city = "null";
                                    String country ="null";
                                    String year = "null";
                                    String lang = "null";
                                    String jds ="null";
                                    String sts ="null";
                String pmid = values [0];
                String fName = values [3];
                String init_name = values [2];
                String email = values [6];
                String organ = values [8];
                String coauthors = values [5];
                String org_desc = values [9];
                String org_type = values[10];
                String inx = values [11];
                pmid_city_country.put(values[0], values[10]+"\t"+values[11]);
//                System.out.println("PMID "+pmid+" "+locs.get(pmid));
                String tmp_locs = locs.get(pmid);
                if(tmp_locs!=null){
                    if(!tmp_locs.contains("null")){
                        String [] tmp_city = locs.get(pmid).split("\t");
                        city = tmp_city[0];
                        country = tmp_city[1];
                    }
                
                }
                String tmp_lyears =lyears.get(pmid);
                if(tmp_lyears!=null){
                    if(!lyears.get(pmid).contains("null")){
                        String[] tmp_yeLang = lyears.get(pmid).split("\t");
                        lang = tmp_yeLang[0];
                        year = tmp_yeLang[1];
                    }
                }
                
                if(jdst.get(pmid)!=null||!jdst.get(pmid).contains("null")){
                    String [] tmp_jdst = jdst.get(pmid).split("\t");
                    jds = tmp_jdst [0];
                    sts = tmp_jdst[1];
                }
                AuthorCand candidate = new AuthorCand(fName, init_name, jds, coauthors, pmid, organ, city, country, email, year, inx, lang, sts, org_type, org_desc);
                candidat_lst.add(candidate);
            }
          //create pairs, print vectors
          
           
        } catch (IOException e) {
            e.printStackTrace();
        }
        
     this.lst_cands = candidat_lst;
    }
    private void splitValuesSong(File fname, QuerySolr solr ) throws SolrServerException, FileNotFoundException, IOException{
        String line = "";
        
        String cvsSplitBy = "\t";
        Set <AuthorCand> candidat_lst = new HashSet();
      
       
        BufferedReader br = new BufferedReader(new FileReader(fname));

            while ((line = br.readLine()) != null) {

              
                String[] values = line.split(cvsSplitBy);
                                 
                    
                     String pmid1 = values[0];
                     String lname1 = values[1];
                     String init1 = values [2];
        String fName1 = values[3];
        String coauthors1 =values[5];
        String affil1 = values[8];
        String id = values [10];      
               
              AuthorCand candidate = new AuthorCand(lname1, fName1, init1, pmid1, affil1, coauthors1, solr, id);
               
                candidat_lst.add(candidate);
            }
          //create pairs, print vectors
          
           
        
        
     this.lst_cands = candidat_lst;
    }
}
