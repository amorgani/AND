/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author VISHNYAD
 */
public class DirReader {
private Map <String,String> mapLoc ;
private Map <String,String> mapJDST ;
private Map <String,String> mapLangYear ;

    public Map<String, String> getMapLangYear(String fileName) throws IOException {
        readYearLang(fileName);
        return mapLangYear;
    }



    public Map<String, String> getMapLoc(String fileName) {
        readLoc(fileName);
        return mapLoc;
    }

    public Map<String, String> getMapJDST(String fileName) {
        readJDST(fileName);
        return mapJDST;
    }


  
  private void readLoc (String fileName){
     
        String line = "";
        String cvsSplitBy = "\t";
        Map <String, String> pmid_city_country = new HashMap();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] values = line.split(cvsSplitBy);
                pmid_city_country.put(values[0], values[10]+"\t"+values[11]);
                

            }
          this.mapLoc = pmid_city_country;
        } catch (IOException e) {
            e.printStackTrace();
        }
   }
   
    private void readJDST (String fileName){
     
        String line = "";
        String cvsSplitBy = "\t";
        Map <String, String> pmid_jd_st = new HashMap();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] values = line.split(cvsSplitBy);
                 pmid_jd_st.put(values[0], values[1]+"\t"+values[2]);
                

            }
          this.mapJDST =  pmid_jd_st;
        } catch (IOException e) {
            e.printStackTrace();
        }
   }
    
   private void readYearLang (String fileName) throws FileNotFoundException, IOException{
     
        String line = "";
        String cvsSplitBy = "\t";
        Map <String, String> lang_year = new HashMap();
         BufferedReader br = new BufferedReader(new FileReader(fileName));

                // use comma as separator
            while ((line = br.readLine()) != null) {
                String[] values = line.split(cvsSplitBy);
                lang_year.put(values[0], values[1]+"\t"+values[2]);
                

            }
            
                
          this.mapLangYear = lang_year;
        
   }
   
}
