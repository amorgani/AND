/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler;

import com.wcohen.ss.JaroWinklerTFIDF;
import comparator.SimilarityComparator;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import modeler.row.AuthorCand;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;

/**
 *
 * @author VISHNYAD
 */
public class CandidateParser {
    private List <String> vectors;

    public List<String> getVectors() {
        return vectors;
    }
    
    
    public void getCandidate(List <String> cand_name_pmid,JaroWinklerTFIDF jaro, SimilarityComparator comparator, HashMap <String, Double> amb_scr) throws SolrServerException, IOException{
        QuerySolr solr = new QuerySolr();
        List <String> vectors = new ArrayList();
    for (String cand: cand_name_pmid){
        String [] info = cand.split("\t");
        String pmid1 = info [0];
        String lname1 = info[1];
        String init1 = info [2];
        String fName1 = info [3];
        String coauthors1 = info[5];
        String affil1 = info[8];
        
        String pmid2 = info [11];
        String lname2 = info[12];
        String init2 = info[13];
        String fName2=info[14];
        String coauthors2 = info[16];
        String affil2 = info[19];
        String id = info[22].toLowerCase();
            
        AuthorCand candidate1 = new AuthorCand(lname1, fName1, init1, pmid1, affil1, coauthors1, solr, id);
        AuthorCand candidate2 = new AuthorCand(lname2, fName2, init2, pmid2, affil2, coauthors2, solr, id);
        double scr = 0.00;
        String tmp_ns = lname1+" "+init1;
        tmp_ns= tmp_ns.toLowerCase();
        if(amb_scr.containsKey(tmp_ns)){
            scr = amb_scr.get(tmp_ns);
        }
        
//        System.out.println(lname1+" "+fName1+" "+init1+" "+pmid1+" "+affil1+" "+coauthors1+" "+id);
        String out = comparator.compareCandidates(candidate1, candidate2, jaro, scr );
//        System.out.println(out);
        vectors.add(out);
    }
    this.vectors = vectors;
    }
}
