/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeler.row;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;

/**
 *
 * @author VISHNYAD
 */
public class AuthorCand {
     private String fname;
    private String initial;
 
    private Set <String> j_dsc = new HashSet();
    private Set <String> sts_dsc = new HashSet();
    private Double org_type = 0.0;
    private Double org_desc =0.0;
    private String pmid;
    private List<String> coautors;

    private String affil_full;
    private String city;
    private String country;
    private String email;

    private int year;
    private String id;
    private String lang;
  private String lname; 
    private int lstname_length;

   

    public int getLstname_length() {
        return lstname_length;
    }
    
    
    
     public AuthorCand(String fname, String initial,  String j_dsc,  String coautors,   String pmid, String organ, String city, String country, String email, String year, String id, String lang, String sts, String org_type, String org_desc) {
        this.fname = fname;
        this.initial = initial;
        if(year.contains("null")) this.year = 0;
        else this.year = Integer.parseInt(year);
        this.lang = lang;
        this.id = id;
        this.org_desc = Double.parseDouble(org_desc) ;
        this.org_type=Double.parseDouble(org_type); 
        String [] dsc = j_dsc.split("\\|");  
        for (String dsc1 : dsc) {
            this.j_dsc.add(dsc1.trim());
        }
        String [] sts_dsc = sts.split("\\|");  
        for (String sc1 : sts_dsc) {
            this.sts_dsc.add(sc1.trim());
        }
        this.affil_full = organ;
        this.email = email;
        this.city = city;
        this.country = country;
               
        String [] authors = coautors.split(",");
        this.coautors =  Arrays.stream(authors).collect(Collectors.toList());
      
      
      
        this.pmid=pmid;
    }
     public AuthorCand( String lname, String fname, String initial, String pmid, String affil, String coauts, QuerySolr solr, String id) throws SolrServerException, IOException {
        this.fname = fname;
        this.initial = initial;
        String tmp = solr.getYearsLang(pmid, solr.getSolr_yl());
        String [] tmps = tmp.split(";");
       
        String year1 = tmps[1];
        String lang1 = tmps [0];
        int tmp_lst = lname.length();
        this.lname = lname;
        this.lstname_length = tmp_lst;
        if(year1.contains("null")) this.year = 0;
        else this.year = Integer.parseInt(year1);
        
        this.lang = lang1;
        
        this.id = id;
        
        String org_desc_solr = solr.getLocs(pmid, lname, solr.getSolr_locs());
      
        String country_solr = "";
        String city_solr = "";
        String email_solr = "";
        String[] tmp_loc = org_desc_solr.split("\t");
        if (tmp_loc.length>=3){
        country_solr = tmp_loc[2];
        }
        if (tmp_loc.length>=4){
            city_solr = tmp_loc[3];
        }
        if (tmp_loc.length>=5){
            email_solr = tmp_loc[4];
        }
        if(tmp_loc.length>=1){
            if(!tmp_loc[0].contains("null")){
                this.org_desc = Double.parseDouble(tmp_loc[0]) ;
            }
        }
        if(tmp_loc.length>=2){
             if(!tmp_loc[1].contains("null")){
                this.org_type=Double.parseDouble(tmp_loc[1]); 
             }
        }
        
        
        
        String descr = solr.getJDST(pmid, solr.getSolr_jds());
        String [] descs = descr.split("\t");
        
        String jds = descs[0];
        String sts="";
        if(descs.length>=2){
            sts = descs[1];
        
        }
        String [] dsc = jds.split("\\|");  
        for (String dsc1 : dsc) {
            this.j_dsc.add(dsc1.trim());
        }
            String [] sts_dsc_solr = sts.split("\\|");  
        for (String sc1 : sts_dsc_solr) {
            this.sts_dsc.add(sc1.trim());
        }
        
        
        this.affil_full = affil;
        this.email = email_solr;
        this.city = city_solr;
        this.country = country_solr;
               
        String [] authors = coauts.split(",");
        this.coautors =  Arrays.stream(authors).collect(Collectors.toList());
      
      
      
        this.pmid=pmid;
    }

    public String getAffil_full() {
        return affil_full;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public String getFname() {
        return fname;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public Set<String> getJ_dsc() {
        return j_dsc;
    }

    public String getPmid() {
        return pmid;
    }

    public int getYear() {
        return year;
    }

    public String getLname() {
        return lname;
    }

    public Set<String> getSts_dsc() {
        return sts_dsc;
    }

    public Double getOrg_type() {
        return org_type;
    }

    public Double getOrg_desc() {
        return org_desc;
    }

    public String getLang() {
        return lang;
    }

    public List<String> getCoautors() {
        return coautors;
    }

    public String getInitial() {
        return initial;
    }


}
