/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import com.wcohen.ss.JaroWinklerTFIDF;
import comparator.SimilarityComparator;
import java.io.IOException;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import modeler.CandidateParser;
import modeler.PairsReader;
import org.apache.solr.client.solrj.SolrServerException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import stat.NameSpacer;
/**
 *
 * @author VISHNYAD
 */
public class RunModel {
      public static void main(String[] args) throws SolrServerException, IOException{
        PairsReader preader = new PairsReader();
          CandidateParser parser = new CandidateParser();
            preader.readPairs("C:\\Users\\vishnyad\\Desktop\\crowdSource\\new\\1804_GS_answers_merged.csv");
            JaroWinklerTFIDF jaro = new JaroWinklerTFIDF();
            SimilarityComparator comparator = new SimilarityComparator();
            NameSpacer ns = new NameSpacer("C:\\Users\\vishnyad\\Desktop\\namesp.csv");
            
            parser.getCandidate(preader.getLst(), jaro, comparator, ns.getAmbig_vals());
            System.out.println("OUT "+parser.getVectors().size());
            
            Path path = Paths.get("C:\\Users\\vishnyad\\Desktop\\crowdSource\\new\\models\\1804_GS_answers_v4.arff");
           Files.write(path, parser.getVectors(), UTF_8, APPEND, CREATE);
    }
}
