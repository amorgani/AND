/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeler.NameSpacesReader;
import org.apache.solr.client.solrj.SolrServerException;
import solr.connector.QuerySolr;
import stat.NameSpacer;

/**
 *
 * @author VISHNYAD
 */
public class RunSong {
      public static void main(String[] args) throws IOException, SolrServerException {
        String ns = "C:\\Users\\vishnyad\\Desktop\\MinSongNS\\20_1\\";
        String out = "C:\\Users\\vishnyad\\Desktop\\crowdSource\\new\\models\\outSongvectorsAmg_20_1.arff";
       
        NameSpacesReader nsr = new NameSpacesReader();
        NameSpacer nspar = new NameSpacer("C:\\Users\\vishnyad\\Desktop\\namesp.csv");
         QuerySolr solr = new QuerySolr();
          try {
              nsr.readNSsong(ns,out, nspar, solr);
          } catch (IOException ex) {
              Logger.getLogger(RunSong.class.getName()).log(Level.SEVERE, null, ex);
          }
        
    }
}
