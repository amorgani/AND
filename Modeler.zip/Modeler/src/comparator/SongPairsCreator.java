/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparator;

import com.wcohen.ss.JaroWinklerTFIDF;
import java.io.IOException;
import static java.nio.charset.StandardCharsets.UTF_8;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import modeler.row.AuthorCand;
import stat.NameSpacer;

/**
 *
 * @author VISHNYAD
 */
public class SongPairsCreator {
        public void doPairs(Set <AuthorCand> candidate_lst, String outputFile, NameSpacer amb) throws IOException{
        Set <AuthorCand> dbl_canAuthorCands = new HashSet();
        dbl_canAuthorCands.addAll(candidate_lst);
        JaroWinklerTFIDF jaro = new JaroWinklerTFIDF();
        SongSimilarityComparator comparator = new SongSimilarityComparator();
        List <String> vectors = new ArrayList();
        
        Path path = Paths.get(outputFile);
        //Creating pairs
        for (AuthorCand candidate_1 : candidate_lst){
            double scr = 0.00;
            dbl_canAuthorCands.remove(candidate_1);
            String fname_1 = candidate_1.getFname();
        String tmp_ns = candidate_1.getLname()+" "+candidate_1.getInitial().substring(0, 1);
      
        tmp_ns= tmp_ns.toLowerCase();
        if(amb.getAmbig_vals().containsKey(tmp_ns)){
            HashMap <String, Double> as = amb.getAmbig_vals();
            scr = as.get(tmp_ns);
        }
            for (AuthorCand candidate_2:dbl_canAuthorCands){
            String fname_2 = candidate_2.getFname();
            System.out.println("Comparing "+fname_1+" "+fname_2);
               
                   
                   String out = comparator.compareCandidates(candidate_1, candidate_2, jaro, scr);
                   if(!out.isEmpty()){
                      //проверить out если первое 0.0 то не пишем
                        vectors.add(out);
                   }
               
            }
            
        }
        //print results in the list
        
       
        Files.write(path, vectors, UTF_8, APPEND, CREATE);
        
    
    }
}
