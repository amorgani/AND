/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparator;

import com.wcohen.ss.JaroWinklerTFIDF;

import static java.nio.charset.StandardCharsets.UTF_8;
import java.nio.file.Files;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import modeler.row.AuthorCand;
/**
 *
 * @author VISHNYAD
 */
public class PairsCreator {
    public void doPairs(Set <AuthorCand> candidate_lst, String outputFile) throws IOException{
        Set <AuthorCand> dbl_canAuthorCands = new HashSet();
        dbl_canAuthorCands.addAll(candidate_lst);
        JaroWinklerTFIDF jaro = new JaroWinklerTFIDF();
        SimilarityComparator comparator = new SimilarityComparator();
        List <String> vectors = new ArrayList();
        
        Path path = Paths.get(outputFile);
        //Creating pairs
        for (AuthorCand candidate_1 : candidate_lst){
            dbl_canAuthorCands.remove(candidate_1);
            String fname_1 = candidate_1.getFname();
            for (AuthorCand candidate_2:dbl_canAuthorCands){
            String fname_2 = candidate_2.getFname();
            System.out.println("Comparing "+fname_1+" "+fname_2);
                if(comparator.isFNamesEqual(fname_1, fname_2, jaro)){
                   
                   String out = comparator.compareCandidates(candidate_1, candidate_2, jaro);
                   if(!out.isEmpty()){
                        vectors.add(out);
                   }
                }
            }
            
        }
        //print results in the list
        
       
        Files.write(path, vectors, UTF_8, APPEND, CREATE);
        
    
    }
    
    
}
