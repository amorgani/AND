/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparator;

/**
 *
 * @author VISHNYAD
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.impl.DenseDoubleMatrix1D;
import com.wcohen.ss.JaroWinklerTFIDF;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Set;
import modeler.row.AuthorCand;
import org.apache.commons.lang3.StringUtils;
/**
 *
 * @author vishnyad
 */
public class SongSimilarityComparator {






    public boolean isFNamesEqual(String fname1, String fname2){
        boolean flag=false;
        fname1 = fname1.replace("-", "");
        fname2 = fname2.replace("-", "");
        fname1 = fname1.replace(" ", "");
        fname2 = fname2.replace(" ", "");
       
           
                        if(fname1.substring(0,1).equals(fname2.substring(0, 1))){
                            flag=true;
                        }

    return flag;
    }
    
    
    public Double compareNames(String fname1, String fname2, JaroWinklerTFIDF jaro, DecimalFormat df){
      double score= 0.0;
       fname1 = fname1.replace("-", "");
        fname2 = fname2.replace("-", "");
        fname1 = fname1.replace(" ", "");
        fname2 = fname2.replace(" ", "");
        if(fname1.contains("null")&&fname2.contains("null")){
            score = 0.01;
            System.out.println("HIT1");
        }
        else{
            if(fname1.length()>3&&fname2.length()>3){
                 score =jaro.score(fname1, fname2);
                String tmp = df.format(score);
                score = Double.parseDouble(tmp);
                System.out.println("HIT2");
            }
            else if (fname1.length()==3&&fname2.length()==3){
                
                 if(countUpper(fname2)>=2||countUpper(fname1)>=2){
                    
                    String n2 = getOnlyUpper(fname2);
                    String n1 = getOnlyUpper(fname1);
                    if(n1.equals(n2)){score=0.2;}
                    else if (n1.contains(n2)||n2.contains(n1)){
                    score=0.1;}
                    System.out.println("HIT3");
                }
                 else {
                     
                     score =jaro.score(fname1, fname2);
                     String tmp = df.format(score);
                     score = Double.parseDouble(tmp);
                     System.out.println("HIT4");
                 }
            }
          
            else if(countUpper(fname2)>=2||countUpper(fname1)>=2){
                    if(fname1.length()>3&&fname2.length()==2){
                        if (countUpper(fname2)==2){
                             String n2 = getOnlyUpper(fname2);
                        String n1 = getOnlyUpper(fname1);
                        if (n1.equals(n2)){
                            score=0.2;
                            System.out.println("HIT5a");
                        }
                        else if (n1.contains(n2)||n2.contains(n1)){
                        score=0.13;}
                        System.out.println("HIT6a");
                        }
                        else {
                         score =jaro.score(fname1, fname2);
                         String tmp = df.format(score);
                         score = Double.parseDouble(tmp);
                         System.out.println("HIT10");
                        } 
                    }
                    else if (fname2.length()>3&&fname1.length()==2){
                         if (countUpper(fname1)==2){
                             String n2 = getOnlyUpper(fname2);
                        String n1 = getOnlyUpper(fname1);
                        if (n1.equals(n2)){
                            score=0.2;
                            System.out.println("HIT5b");
                        }
                        else if (n1.contains(n2)||n2.contains(n1)){
                        score=0.1;}
                        System.out.println("HIT6b");
                        }
                         else {
                         
                            score =jaro.score(fname1, fname2);
                             String tmp = df.format(score);
                             score = Double.parseDouble(tmp);
                             System.out.println("HIT11");
                         }
                    }
                    else {
                        String n2 = getOnlyUpper(fname2);
                        String n1 = getOnlyUpper(fname1);
                        if (n1.equals(n2)){
                            score=0.2;
                            System.out.println("HIT5");
                        }
                        else if (n1.contains(n2)||n2.contains(n1)){
                        score=0.1;}
                        System.out.println("HIT6");
                    }
                    
                }
             
       else if(fname1.length()<2||fname2.length()<2){
               System.out.println("HIT7");
                    String n2 = getOnlyUpper(fname2);
                    String n1 = getOnlyUpper(fname1);
                    if(n2.equals(n1)){score =0.15;
                    System.out.println("HIT8");
                    }
               
              
        
            }
       else if(fname1.length()<2&&fname2.length()<2){
             
                    String n2 = getOnlyUpper(fname2);
                    String n1 = getOnlyUpper(fname1);
                    if(n2.equals(n1)){
                        score =0.1;
                        System.out.println("HIT9");
                    }
               
              
        
            }
       
   
        }
        System.out.println("Name1: "+fname1+" Name2: "+fname2+" score: "+score);
    return score ;
    }
     private int countUpper(String str){
    int count =0;
        for (int i=0; i<str.length(); i++){
            if (Character.isUpperCase(str.charAt(i))){
                count ++;
            }
        }
        System.out.println("COUNT: "+count);
    return count;
    }
     public String getOnlyUpper(String str) {
        
      String out="";
 
    for (int i = 0; i < str.length(); i++) {
    
            if(Character.isUpperCase(str.charAt(i))){    
             out=out+str.charAt(i);
            }
            
 }
    System.out.println("Upper: "+out);
 return out;
     }
    public String compareCandidates ( AuthorCand author1, AuthorCand author2, JaroWinklerTFIDF jaro, double ambig_scr){
        DecimalFormat df = new DecimalFormat("#.####");
        df.setRoundingMode(RoundingMode.CEILING);
        int class_pairs =0;
        String out = "";
        int jds =0;
        int sts =0;
       
       double names = compareNames(author1.getFname(), author2.getFname(), jaro, df);
        int cities = compareCities(author1.getCity(), author2.getCity());
        int countries = compareCountries(author1.getCountry(), author2.getCountry());
        int lst_name_length = author1.getLstname_length();
        double email =compareEmail(author1.getEmail(), author2.getEmail(),  jaro);
        String emails = df.format(email);
       int langs = compareLang(author1.getLang(), author2.getLang());
       int years =  compareYears(author1.getYear(), author2.getYear());
       int coautors= findSimilarCoAutrs(author1.getCoautors(), author2.getCoautors(), jaro);
      jds =  calcSimJDesc(author1.getJ_dsc(), author2.getJ_dsc());
      sts=  calcSimJDesc(author1.getSts_dsc(), author2.getSts_dsc());
      DoubleMatrix1D a = new DenseDoubleMatrix1D(new double[]{author1.getOrg_desc(),author1.getOrg_type()});
      DoubleMatrix1D b = new DenseDoubleMatrix1D(new double[]{author2.getOrg_desc(),author2.getOrg_type()});
      double cosineDistance = a.zDotProduct(b)/Math.sqrt(a.zDotProduct(a)*b.zDotProduct(b));
      
        if(Double.isNaN(cosineDistance)){
            cosineDistance= 0.0;
        }
      double orgs = jaro.score(author1.getAffil_full(), author2.getAffil_full());
      String orgsAB = df.format(orgs);
      String cosDistAB = df.format(cosineDistance);
      double inits = jaro.score (author1.getInitial(),author2.getInitial());
      String innitials = df.format(inits);
//      if(author1.getId().equalsIgnoreCase(author2.getId())){
//      class_pairs=1;
//      out = names+","+coautors+","+orgsAB+","+jds+","+sts+","+emails+","+countries+","+cities+","+langs+","+years+","+cosDistAB+","+innitials+","+class_pairs;
//      }
        if(author1.getId().equalsIgnoreCase(author2.getId())){
         class_pairs=1;
         out = names+","+coautors+","+orgsAB+","+jds+","+sts+","+emails+","+countries+","+cities+","+langs+","+years+","+cosDistAB+","+lst_name_length+","+innitials+","+ambig_scr+","+class_pairs;
//        System.out.println("OUT: "+out);
        }
       
        else {
            if(names!=0.0){
                class_pairs=0;
                out = names+","+coautors+","+orgsAB+","+jds+","+sts+","+emails+","+countries+","+cities+","+langs+","+years+","+cosDistAB+","+lst_name_length+","+innitials+","+ambig_scr+","+class_pairs;
            }
            

        }
        
        return out;
    }
    public int compareCities (String city1, String city2){
      int flag_citi = 0;
      int flag_null = 0;
      if(city1.contains("null")||city2.contains("null")){
          flag_null = -1;
      }
      else {
                if(city2.contains(",")){
                              String[] citi;
                              citi = city2.split(",");
                              for (String citi1 : citi) {
                                  if (city1.toLowerCase().contains(citi1.toLowerCase())) {
                                      flag_citi=1;
                                  }
                              }


                }
                if(city1.contains(",")){
                     String[] citi;
                              citi = city1.split(",");
                              for (String citi1 : citi) {
                                  if (city2.toLowerCase().contains(citi1.toLowerCase())) {
                                      flag_citi=1;
                                  }
                              }
                }
                else {
                    if(city1.equalsIgnoreCase(city2)&&flag_null!=-1) flag_citi=1;
                }
      
      }
                return flag_citi;
    }
    
    public int compareCountries(String country1, String country2){
        int flag = 0;
       int flag_null = 0;
        if(country1.contains("null")||country2.contains("null")){
            flag_null=-1;
           
        }
        else {
                if(country1.contains(",")&&flag!=0){
                      String[] countries;
                                  countries = country1.split(",");
                                  for (String c : countries) {
                                      if (country2.toLowerCase().contains(c.toLowerCase())) {
                                          flag=1;
                                      }
                                  }

                }
                if(country2.contains(",")&&flag!=0){
                      String[] countries;
                                  countries = country2.split(",");
                                  for (String c : countries) {
                                      if (country1.toLowerCase().contains(c.toLowerCase())) {
                                          flag=1;
                                      }
                                  }

                }
                if(country1.equalsIgnoreCase(country2)&&flag_null!=-1)flag = 1;
        
        }
        return flag;
    }
    
    public int compareYears (int year1, int year2){
        int diff =0;
        if(year1==0||year2==0)diff = 0;
        if(year1>year2)diff = year1-year2;
        if(year2>year1) diff = year2-year1;
        if(diff>1000) diff = -1;
        return diff;
    
    }
    public double compareEmail(String email1, String email2, JaroWinklerTFIDF jaro){
//        int diff =0;
//        boolean flag = false;
//        if(email1.equalsIgnoreCase("null")&&email2.equalsIgnoreCase("null")){
//        diff =-2;
//        flag = true;
//        } 
//        if(email1.equalsIgnoreCase("null")&&!email2.equalsIgnoreCase("null")){
//        diff =-1;
//        flag = true;
//        } 
//        if(!email1.equalsIgnoreCase("null")&&email2.equalsIgnoreCase("null")){
//        diff =-1;
//        flag = true;
//        } 
//        if(email1.equalsIgnoreCase(email2)&&!flag) diff=1;
//        System.out.println(email1+"    "+email2+"    ="+diff);
//        return diff;
        double diff =0.0;
       
        if(email1.equalsIgnoreCase("null")&&email2.equalsIgnoreCase("null")){
        diff =0.0;
       
        } 
        if(email1.equalsIgnoreCase("null")&&!email2.equalsIgnoreCase("null")){
        diff =0.0;
       
        } 
        if(!email1.equalsIgnoreCase("null")&&email2.equalsIgnoreCase("null")){
        diff =0.0;
       
        } 
        if(!email1.equalsIgnoreCase("null")&&!email2.equalsIgnoreCase("null")) diff=1;
        diff= jaro.score(email1, email2);
        System.out.println(email1+"    "+email2+"    ="+diff);
        return diff;
                
    }
    public int compareLang (String lang1, String lang2){
        int diff = 0;
        boolean flag = false;
        if(lang1.equalsIgnoreCase("null")||lang2.equalsIgnoreCase("null")) {
        diff = 0;flag = true;
        }
        if(lang1.equalsIgnoreCase(lang2)&&!flag) diff=1;
        else diff =2;
        return diff;
    }
    public int calcSimJDesc (Set <String> jd1, Set <String> jd2){
        int count=0;
        boolean flag_null = false;
        if(jd1.isEmpty()||jd2.isEmpty()){
        count=0;
        flag_null=true;
        }
        else if (!flag_null){
            
            for (String jds: jd1){
                if(jd2.contains(jds)) count++;
            }
            
        }
         System.out.println("jd1 "+jd1+" jd2 "+jd2+" sum"+count);
        return count;
    }
    public int findSimilarCoAutrs(List <String> coa1, List <String> coa2, JaroWinklerTFIDF jaro){
      
        int count=0;
        double scr;
       
        if(coa1.isEmpty()||coa2.isEmpty()){count =0;
        
        }
        else{
                for(String ent_coa1: coa1){
                    for(String ent_coa2: coa2){
                       scr= jaro.score(ent_coa1, ent_coa2);
                       if (scr>=0.99)count++;
                    }
                  
                }
        }
        System.out.println("A1 "+coa1+"    A2: "+coa2+"      ="+count);
        return count;
    }
    }


