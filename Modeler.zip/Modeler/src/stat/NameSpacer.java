/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stat;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;

/**
 *
 * @author VISHNYAD
 */
public class NameSpacer {
private HashMap ambig_vals;

    public NameSpacer(String fileAmb) throws FileNotFoundException, IOException {
         BufferedReader br = new BufferedReader(new FileReader(fileAmb));
        String line = null;
        HashMap<String, Double> map = new HashMap<String, Double>();
        DecimalFormat df2 = new DecimalFormat(".##");
        while ((line = br.readLine()) != null) {
            String str[] = line.split(";");
                    String name = str[1].replace(".csv", "");
                    name = name.replace("_", " ");
                    double val_tmp = Double.parseDouble(str[2]);
                    String  val = df2.format(val_tmp);
                map.put(name, Double.parseDouble(val));
            
        }
        this.ambig_vals= map;
    }

    public HashMap getAmbig_vals() {
        return ambig_vals;
    }

  
    
    

}
